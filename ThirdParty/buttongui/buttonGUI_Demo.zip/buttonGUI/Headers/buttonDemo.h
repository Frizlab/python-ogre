#ifndef __buttonDemo_H__
#define __buttonDemo_H__
#if _MSC_VER > 1000
#pragma once
#endif

#include "Ogre.h"
#include "InputManager.h"
#include "buttonGUI.h"

class buttonDemo : public OIS::MouseListener, public OIS::KeyListener, public Ogre::WindowEventListener
{
	Ogre::RenderWindow* renderWin;
	Ogre::SceneManager* sceneMgr;
	buttonGUI::buttonManager* buttonMgr;
	buttonGUI::InputManager* inputMgr;
	void parseResources();
	void loadInputSystem();
public:
	bool shouldQuit;
	buttonDemo();
	~buttonDemo();

	void createScene();
	void setupButtons();

	void Update();

	void handleButtonEvent(buttonGUI::buttonEvent * e);
	
	bool mouseMoved(const OIS::MouseEvent &arg);
	bool mousePressed(const OIS::MouseEvent &arg, OIS::MouseButtonID id);
	bool mouseReleased(const OIS::MouseEvent &arg, OIS::MouseButtonID id);

	bool keyPressed( const OIS::KeyEvent &arg );
	bool keyReleased( const OIS::KeyEvent &arg );	

	void windowMoved(Ogre::RenderWindow* rw);
	void windowResized(Ogre::RenderWindow* rw);
	void windowClosed(Ogre::RenderWindow* rw);
	void windowFocusChange(Ogre::RenderWindow* rw);
};

#endif