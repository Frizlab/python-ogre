import sys
import os.path
import inspect


class TestGenerator(object):
    """Generate a set of unit tests for given class."""

    # a list of method we *don't* want to wrap that can be augmented during
    # the initialization of a particular class.
    DONT_GENERATE = (
        '__del__', '__repr__', '__str__', '__weakref__')
    
    def __init__(self, cls, path, basename, verbose=True):
        """Initialize the generator."""
        self._cls = cls
        self._clsname = basename+'Tests'
        self._filename = os.path.join(path, 'BaseTest'+basename+'.py')
        self._verbose = verbose
        self._old = None
        
        # execute 'filename' in a safe place to load existing tests
        if os.path.exists(self._filename):
            container = {}
            execfile(self._filename, container, container)
            for k, v in container.items():
                if k == self._clsname:
                    self._old = v
                    break

        # build the temporary "don't generate" list
        self._dont = tuple(self.DONT_GENERATE)
        
    def _make_name(self, method):
        """Generate a name for given method."""
        return 'test_'+method

    def _check(self, method):
        """Check if given method already exists as a test."""
        testname = self._make_name(method)
        if self._old and hasattr(self._old, testname):
            return True
        elif method in self._dont:
            return True
        else:
            return False

    def _write_header(self, stream):
        """Write generic header and class declaration."""
        stream.write("# %s - unit tests for the %s class\n\n" % (
            os.path.basename(self._filename), self._cls.__name__))
        stream.write("class %s(object):\n" % self._clsname)
        stream.write('    """Test cases for %s."""\n' % self._cls.__name__)
        
    def _write_method(self, stream, methname):
        testname = self._make_name(methname)
        stream.write("\n")
        stream.write("    def %s(self):\n" % testname)
        stream.write('        """Unit test for %s.%s()"""\n'
                     % (self._cls.__name__, methname))
        stream.write("        self.fail('test case not implemented')\n")
        self.log("    %s: %s", methname, testname)
        
    def _write_attribute(self, stream, attrname):
        testname = self._make_name(attrname)
        stream.write("\n")
        stream.write("    def %s(self):\n" % testname)
        stream.write('        """Unit test for %s.%s"""\n'
                     % (self._cls.__name__, attrname))
        stream.write("        self.fail('test case not implemented')\n")
        self.log("    %s: %s", attrname, testname)

    def log(self, msg, *args):
        if not self._verbose:
            return
        if args:
            msg = msg % args
        print msg
        
    def generate(self):
        """Generate the unit tests and write them to filename."""
        if self._old is None:
            stream = open(self._filename, 'w')
            self._write_header(stream)
        else:
            stream = open(self._filename, 'a')
            stream.seek(0, 2)

        if self._old is None:
            self.log("N %s (%s):", self._cls.__name__, self._filename)
        else:
            self.log("  %s (%s):", self._cls.__name__, self._filename)
        
        for methname, meth in inspect.getmembers(self._cls, inspect.ismethod):
            if self._check(methname): continue
            self._write_method(stream, methname)
            
        for attrname, attr in \
                inspect.getmembers(self._cls, inspect.isdatadescriptor):
            if self._check(attrname): continue
            self._write_attribute(stream, attrname)

        # generate return the right "from/import" for a TestCase wrapper
        toReturn  = "try:\n"
        toReturn += "    from %s import *\n" % os.path.basename(self._filename)[:-3][4:]
        toReturn += "except ImportError, ie:\n"
        toReturn += "    print 'Failed import: %s'\n" % os.path.basename(self._filename)[:-3][4:]
        return toReturn
    
## parse arguments, execute main loop ##
            
if len(sys.argv) < 3:
    sys.stderr.write("Usage: %s <path> <module> <class1> ...\n" % sys.argv[0])
    sys.exit(1)

PATH = sys.argv[1]
MODULE = sys.argv[2]

if len(sys.argv) > 3:
    CLASSES = tuple(sys.argv[3:])
else:
    CLASSES = None

# add PATH to the python path to make sure we'll import the test modules
# without any problem
if PATH and PATH not in sys.path:
    sys.path.append(PATH)

# FIXME: this will use MODULE in the future
from pyogre import ogre

# generate tests for all classes in the module
imports = []
for clsname, cls in inspect.getmembers(ogre, inspect.isclass):
    if clsname.endswith('Ptr') or clsname.startswith('_'):
        continue
    if CLASSES is not None and clsname not in CLASSES:
        continue

    g = TestGenerator(cls, PATH, clsname)
    imports.append(g.generate())

# generate the testall.py file
stream = open(os.path.join(PATH, 'testall.py'), 'w')
stream.write("# testall.py - import and executes all tests "
              "for the %s module\n\n" % MODULE)
stream.write("import unittest\n\n")
stream.write("\n".join(imports) + "\n\n")
stream.write("if __name__ == '__main__':\n")
stream.write("    unittest.main()\n")
