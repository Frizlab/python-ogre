# setup.py - distutils packaging
#
# Copyright (C) 2005 PyOgre Core Team
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 2, or (at your option) any later
# version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTIBILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.

"""Ogre bindings
 
The pyogre module provides Python binding to the Ogre3D framework and to the
Ogre version of the CEGUI library.
"""

classifiers = """\
Development Status :: 4 - Beta
Intended Audience :: Developers
License :: OSI Approved :: GNU Lesser General Public License (LGPL)
Programming Language :: Python
Programming Language :: C++
Topic :: Software Development
Topic :: Software Development :: Libraries :: Python Modules
Operating System :: Microsoft :: Windows
Operating System :: Unix
"""

PYOGRE_VERSION = '1.0.6-0'

import sys
import os
import os.path
from distutils.core import setup, Extension
from distutils.errors import DistutilsFileError
from distutils.command.build_ext import build_ext
from distutils.command.build import build
from distutils.dep_util import newer
from distutils import log

def pkg_config(name, flags):
    f = os.popen('pkg-config %s %s' % (flags, name), 'r')
    try:
        return f.readline().strip().split(' ')
    finally:
        f.close()

class pyogre_Extension(Extension):
    """Some extra options to default Extensions."""
    
    def __init__(self, name, sources, **kwargs):
        self.pkg_config_module = None
	self.pkg_config_generate = None
        self.swig_includes = []
        if 'pkg_config_module' in kwargs:
            self.pkg_config_module = kwargs['pkg_config_module']
            del kwargs['pkg_config_module']
	if 'pkg_config_generate' in kwargs:
	    self.pkg_config_generate = kwargs['pkg_config_generate']
	    del kwargs['pkg_config_generate']
        if 'swig_includes' in kwargs:
            self.swig_includes = kwargs['swig_includes']
            del kwargs['swig_includes']

        Extension.__init__(self, name, sources, **kwargs)

        if hasattr(self, "finalize_" + sys.platform):
            getattr(self, "finalize_" + sys.platform)()

    def finalize_linux2(self):
        """On Linux uses pkg-config to add some options.
	
	This method also generates a local .pc files for extensions that
	need linking against private libraries (this is another horrible
	hack untill we solve the dynamic loader problem on Linux.)
	"""
        if not self.pkg_config_module: return
        pcm = self.pkg_config_module

	if self.pkg_config_generate:
	    prefix = pkg_config(pcm.split()[0], '--variable=prefix')[0] 
	    text = open(self.pkg_config_generate+'.pc.in').read()
	    text = text.replace('@prefix@', prefix)
	    open(self.pkg_config_generate+'.pc', 'w').write(text)
	    os.environ['PKG_CONFIG_PATH'] = \
	        os.environ.get('PKG_CONFIG_PATH', "") + ':' + os.getcwd()
	    pcm += ' ' + self.pkg_config_generate
	    
        self.include_dirs.extend(
            [x[2:] for x in pkg_config(pcm, '--cflags-only-I')])

        self.extra_compile_args = self.extra_compile_args or []
        self.extra_compile_args.extend(pkg_config(pcm, '--cflags-only-other'))

        # TODO: split out libraries, dirs and other stuff
        self.extra_link_args = self.extra_link_args or []
        self.extra_link_args.extend(pkg_config(pcm, '--libs'))

class pyogre_build(build):
    """Reorder the build passes to include SWIG-generated shadow modules."""
    sub_commands = [('build_clib',    build.has_c_libraries),
                    ('build_ext',     build.has_ext_modules),
                    ('build_py',      build.has_pure_modules),
                    ('build_scripts', build.has_scripts)]
    
class pyogre_build_ext(build_ext):
    """Our own build_ext class to take care of SWIG and pkg-config."""

    def finalize_options(self):
        build_ext.finalize_options(self)

        if hasattr(self, "finalize_" + sys.platform):
            getattr(self, "finalize_" + sys.platform)()

    def build_extension(self, ext):
        # horrible hack to pass the current extension to .swig_sources() under
        # Python 2.3
        self._current_ext = ext
        return build_ext.build_extension(self, ext)
        
    def swig_sources(self, sources, ext=None):
        new_sources = []
        swig_sources = []
        swig_targets = {}
        swig_includes = []

        if not ext:
            ext = self._current_ext
        
        for source in sources:
            base, ex = os.path.splitext(source)
            if ex == ".i":
                target = base + '_wrap' + '.cxx'
                new_sources.append(target)
                swig_sources.append(source)
                swig_targets[source] = target
                # include extra files from same directory
                path, _ = os.path.split(target)
                if path not in swig_includes:
                    swig_includes.append(path)
            else:
                new_sources.append(source)

        swig_includes = ['-I'+x for x in swig_includes]
        if ext.pkg_config_module:
            swig_includes.extend(
                pkg_config(ext.pkg_config_module, '--cflags-only-I'))
        swig_includes.extend(ext.swig_includes)

        swig_cmd = [self.find_swig(), "-python", "-c++", "-modern"] + \
                   swig_includes

        for source in swig_sources:
            target = swig_targets[source]
            outdir = os.path.split(os.path.split(target)[0])[0]
            if newer(source, target) or self.force:
                log.info("swigging %s to %s", source, target)
                self.spawn(swig_cmd + ["-o",target,"-outdir",outdir,source])
            else:
                log.info("skipping " + source)

        # hack:  This adds the new cxx files, but it should be
        #        cleaned up, perhaps finding all cxx files and adding them
        if new_sources[0]=='pyogre/ogre/ogre_wrap.cxx':
            new_sources.append('pyogre/ogre/VertexBufferProxy.cxx')
            new_sources.append('pyogre/ogre/IndexBufferProxy.cxx')
        return new_sources
    
# build the extensions
ext_ogre = pyogre_Extension("pyogre._ogre", ["pyogre/ogre/ogre.i"],
    pkg_config_module='OGRE')

ext_cegui = pyogre_Extension("pyogre._cegui", ["pyogre/cegui/cegui.i"],
    pkg_config_module='CEGUI CEGUI-OPENGL CEGUI-OGRE',
    pkg_config_generate='CEGUI-OGRE-PYTHON',
    swig_includes=["-Ipyogre/ogre"])

setup(name="pyogre",
      version=PYOGRE_VERSION,
      maintainer="PyOgre Core Team",
      maintainer_email="fog@initd.org",
      author="PyOgre Core Team",
      author_email="fog@initd.org",
      url="http://developer.berlios.de/projects/pyogre",
      download_url = "https://developer.berlios.de"
                     "/project/showfiles.php?group_id=3464",
      license="LGPL",
      platforms = ["any"],
      description=__doc__.split("\n")[0],
      long_description="\n".join(__doc__.split("\n")[2:]),
      classifiers=filter(None, classifiers.split("\n")),
      data_files=[],
      packages=['pyogre'],
      cmdclass={'build': pyogre_build, 'build_ext': pyogre_build_ext},
      ext_modules=[ext_ogre, ext_cegui])
