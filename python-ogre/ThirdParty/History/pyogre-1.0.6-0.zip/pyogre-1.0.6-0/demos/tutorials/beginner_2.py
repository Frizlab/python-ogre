# this code is in the public domain
# http://www.ogre3d.org/wiki/index.php/PyOgre_Beginner_Tutorial_2
from pyogre import ogre
import SampleFramework

class TutorialApplication(SampleFramework.Application):
    def _createScene(self):
        sceneManager = self.sceneManager
        sceneManager.ambientLight = (0, 0, 0)
        sceneManager.shadowTechnique = ogre.SHADOWTYPE_STENCIL_ADDITIVE

        ent = sceneManager.createEntity("Ninja", "ninja.mesh")
        ent.castShadows = True     # this is not actually needed
        sceneManager.rootSceneNode.createChildSceneNode().attachObject(ent)

        plane = ogre.Plane((0, 1, 0), 0)

        mm = ogre.MeshManager.getSingleton()
        mm.createPlane('ground', ogre.ResourceManager.DEFAULT_RESOURCE_GROUP_NAME,
                       plane, 1500, 1500, 20, 20, True, 1, 5, 5, (0, 0, 1))

        ent = sceneManager.createEntity("GroundEntity", "ground")
        sceneManager.rootSceneNode.createChildSceneNode().attachObject(ent)
        
        ent.setMaterialName("Examples/Rockwall")
        ent.castShadows = False

        # point light
        light = self.sceneManager.createLight("Light1")
        light.type = ogre.Light.LT_POINT
        light.position = (0, 150, 250)
        light.diffuseColour = (1.0, 0.0, 0.0)
        light.specularColour = (1.0, 0.0, 0.0)

        # directional light
        light = sceneManager.createLight("Light3")
        light.type = ogre.Light.LT_DIRECTIONAL
        light.diffuseColour = (.25, .25, 0)
        light.specularColour = (.25, .25, 0)
        light.direction = (0, -1, 1)

        # spotlight
        light = sceneManager.createLight("Light2")
        light.type = ogre.Light.LT_SPOTLIGHT
        light.diffuseColour = (0, 0, 1.0)
        light.specularColour = (0, 0, 1.0)
        light.direction = (-1, -1, 0)
        light.position = (300, 300, 0)
        light.setSpotlightRange(ogre.Degree(35), ogre.Degree(50))
    
    def _createCamera(self):
        self.camera = self.sceneManager.createCamera("PlayerCam")
        self.camera.position = (0, 10, 500)
        self.camera.lookAt((0, 0, 0))

        self.camera.nearClipDistance = 5

    
    def _createViewports(self):
        vp = self.renderWindow.addViewport(self.camera)
        vp.backgroundColour = (0, 0, 0)
        
        self.camera.aspectRatio = vp.actualWidth / vp.actualHeight

if __name__ == '__main__':
    ta = TutorialApplication()
    ta.go()
