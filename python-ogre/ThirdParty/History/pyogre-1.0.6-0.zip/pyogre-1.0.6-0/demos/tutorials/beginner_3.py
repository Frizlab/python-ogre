# this code is in the public domain
# http://www.ogre3d.org/wiki/index.php/PyOgre_Beginner_Tutorial_3
from pyogre import ogre
import SampleFramework

class TutorialApplication(SampleFramework.Application):
    def _createScene(self):
         self.sceneManager.setWorldGeometry("terrain.cfg")
         self.sceneManager.setSkyBox(True, "Examples/SpaceSkyBox")

         # other skybox/dome/plane settings:
         #self.sceneManager.setSkyDome(True, "Examples/CloudySky", 5, 8)

         #plane = ogre.Plane((0, -1, 0), -1000)
         #self.sceneManager.setSkyPlane(True, plane, "Examples/SpaceSkyPlane", 1500, 75)
         #self.sceneManager.setSkyPlane(True, plane, "Examples/SpaceSkyPlane", 1500, 50, True, 1.5, 150, 150)
         #self.sceneManager.setSkyPlane(True, plane, "Examples/CloudySky", 1500, 40, True, 1.5, 150, 150)


##         # fog
##         fadeColour = (0.9, 0.9, 0.9)
##         self.renderWindow.getViewport(0).backgroundColour = fadeColour
##         self.sceneManager.setWorldGeometry("terrain.cfg")
##
##         self.sceneManager.setFog(ogre.FOG_LINEAR, fadeColour, 0, 50, 500)
##         #self.sceneManager.setFog(ogre.FOG_EXP, fadeColour, 0.005)


##         # fog & sky dome
##         self.sceneManager.setWorldGeometry("terrain.cfg")
##         
##         fadeColour = (0.9, 0.9, 0.9)
##         self.sceneManager.setFog(ogre.FOG_LINEAR, fadeColour, 0, 50, 515)
##         self.renderWindow.getViewport(0).backgroundColour = fadeColour
##         
##         self.sceneManager.setSkyDome(True, "Examples/CloudySky", 5, 500)


##         # fog & sky plane
##         self.sceneManager.setWorldGeometry("terrain.cfg")
##         
##         fadeColour = (0.9, 0.9, 0.9)
##         self.renderWindow.getViewport(0).backgroundColour = fadeColour
##         self.sceneManager.setFog(ogre.FOG_LINEAR, fadeColour, 0, 50, 500)
##         
##         plane = ogre.Plane((0, -1, 0), -1000)
##         self.sceneManager.setSkyPlane(True, plane, "Examples/CloudySky", 500, 20, True, 0.5, 150, 150)

##         # fake darkness
##         self.sceneManager.setWorldGeometry("terrain.cfg")
##
##         fadeColour = (0.1, 0.1, 0.1)
##         self.renderWindow.getViewport(0).backgroundColour = fadeColour
##         self.sceneManager.setFog(ogre.FOG_LINEAR, fadeColour, 0.0, 10, 150)
## 
##         plane = ogre.Plane((0, -1, 0), -10)
## 
##         self.sceneManager.setSkyPlane(True, plane, "Examples/SpaceSkyPlane", 100, 45, True, 0.5, 150, 150)

         
    def _chooseSceneManager(self):
        self.sceneManager = self.root.getSceneManager(ogre.ST_EXTERIOR_CLOSE)

if __name__ == '__main__':
    ta = TutorialApplication()
    ta.go()
