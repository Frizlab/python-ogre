# this code is in the public domain
# http://www.ogre3d.org/wiki/index.php/PyOgre_Beginner_Tutorial_5
from pyogre import ogre
import SampleFramework


class TutorialFrameListener(SampleFramework.FrameListener):
    def __init__(self, renderWindow, camera, sceneManager):
        SampleFramework.FrameListener.__init__(self, renderWindow, camera)
        
        # populate the camera and scene manager containers
        self.camNode = camera.parentSceneNode.parentSceneNode
        self.sceneManager = sceneManager
        
        self.rotate = 72            # rotation speed
        self.move = 250             # movement speed
        self.keepRendering = True   # whether to continue rendering or not
        
        # the direction we are currently moving in
        self.direction = ogre.Vector3(0, 0, 0)

    def _setupInput(self):
        self.eventProcessor = ogre.EventProcessor()
        self.eventProcessor.initialise(self.renderWindow)
        self.eventProcessor.startProcessingEvents()

        # register as a listener for events
        self.eventProcessor.addKeyListener(self)
        self.eventProcessor.addMouseListener(self)
        self.eventProcessor.addMouseMotionListener(self)
        
    def frameStarted(self, evt):
        self.camNode.translate(self.camNode.orientation * self.direction * evt.timeSinceLastFrame)
        return self.keepRendering

    def keyPressed(self, evt):
        if evt.key == ogre.KC_ESCAPE:
            self.keepRendering = False

        elif evt.key == ogre.KC_1:
            self.camera.parentSceneNode.detachObject(self.camera)
            self.camNode = self.sceneManager.getSceneNode("CamNode1")
            self.sceneManager.getSceneNode("PitchNode1").attachObject(self.camera)

        elif evt.key == ogre.KC_2:
            self.camera.parentSceneNode.detachObject(self.camera)
            self.camNode = self.sceneManager.getSceneNode("CamNode2")
            self.sceneManager.getSceneNode("PitchNode2").attachObject(self.camera)

        elif evt.key in (ogre.KC_UP, ogre.KC_W):
            self.direction.z -= self.move

        elif evt.key in (ogre.KC_DOWN, ogre.KC_W):
            self.direction.z += self.move

        elif evt.key in (ogre.KC_LEFT, ogre.KC_A):
            self.direction.x -= self.move

        elif evt.key in (ogre.KC_RIGHT, ogre.KC_D):
            self.direction.x += self.move

        elif evt.key in (ogre.KC_PGDOWN, ogre.KC_E):
            self.direction.y += self.move

        elif evt.key in (ogre.KC_PGUP, ogre.KC_Q):
            self.direction.y -= self.move

    def keyReleased(self, evt):
        if evt.key in (ogre.KC_UP, ogre.KC_W):
            self.direction.z += self.move

        elif evt.key in (ogre.KC_DOWN, ogre.KC_W):
            self.direction.z -= self.move

        elif evt.key in (ogre.KC_LEFT, ogre.KC_A):
            self.direction.x += self.move

        elif evt.key in (ogre.KC_RIGHT, ogre.KC_D):
            self.direction.x -= self.move

        elif evt.key in (ogre.KC_PGDOWN, ogre.KC_E):
            self.direction.y -= self.move

        elif evt.key in (ogre.KC_PGUP, ogre.KC_Q):
            self.direction.y += self.move

    def mousePressed(self, evt):
        if evt.buttonID & ogre.MouseEvent.BUTTON0_MASK:
            light = self.sceneManager.getLight("Light1")
            light.visible = not light.visible

    def mouseDragged(self, evt):
        self.camNode.yaw(ogre.Degree(-evt.relX * self.rotate))
        self.camNode.getChild(0).pitch(ogre.Degree(-evt.relY * self.rotate))
            
        
        
     
class TutorialApplication(SampleFramework.Application):
    def _createScene(self):
        sceneManager = self.sceneManager
        sceneManager.ambientLight = 0.25, 0.25, 0.25
        
        ent = sceneManager.createEntity("Ninja", "ninja.mesh")
        node = sceneManager.rootSceneNode.createChildSceneNode("NinjaNode")
        node.attachObject(ent)

        light = sceneManager.createLight("Light1")
        light.type = ogre.Light.LT_POINT
        light.position = 250, 150, 250
        light.diffuseColour = 1, 1, 1
        light.specularColour = 1, 1, 1

        # create the first camera node/pitch node
        node = sceneManager.rootSceneNode.createChildSceneNode("CamNode1", (-400, 200, 400))
        node.yaw(ogre.Degree(-45))  # look at the ninja

        node = node.createChildSceneNode("PitchNode1")
        node.attachObject(self.camera)

        # create the second camera node/pitch node
        node = sceneManager.rootSceneNode.createChildSceneNode("CamNode2", (0, 200, 400))
        node.createChildSceneNode("PitchNode2")

    def _createCamera(self):
        self.camera = self.sceneManager.createCamera("PlayerCam")
        self.camera.nearClipDistance = 5

    def _createFrameListener(self):
        self.frameListener = TutorialFrameListener(self.renderWindow, self.camera, self.sceneManager)
        self.root.addFrameListener(self.frameListener)
        self.frameListener.showDebugOverlay(True)
 
if __name__ == '__main__':
    try:
        ta = TutorialApplication()
        ta.go()
    except ogre.OgreException, e:
        print e
