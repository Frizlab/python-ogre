# this code is in the public domain
import pyogre.ogre as ogre
import SampleFramework as sf

class EnvMapApplication(sf.Application):
    def _createScene( self ):
        sceneManager = self.sceneManager
        camera = self.camera
        
        sceneManager.ambientLight = 0.5, 0.5, 0.5

        light = sceneManager.createLight('MainLight')
        light.position = 20, 80, 50

        entity = sceneManager.createEntity('head', 'ogrehead.mesh')
        entity.setMaterialName("Examples/EnvMappedRustySteel")

        sceneManager.rootSceneNode.createChildSceneNode().attachObject(entity)

if __name__ == '__main__':
    try:
        application = EnvMapApplication()
        application.go()
    except ogre.OgreException, e:
        print e
