# This code is in the Public Domain
import pyogre.ogre as ogre
import SampleFramework as sf

class CameraTrackApplication(sf.Application):
    def _createScene(self):
        sceneManager = self.sceneManager
        
        sceneManager.ambientLight = 0.7, 0.7, 0.7
        sceneManager.setSkyDome(True, 'Examples/CloudySky', 4.0, 8.0)

        light = sceneManager.createLight('MainLight')
        light.position = 20, 80, 50

        plane = ogre.Plane()
        plane.normal = ogre.Vector3.UNIT_Y
        plane.d = 200
        
        mm = ogre.MeshManager.getSingleton()
        mm.createPlane('FloorPlane', 'General', plane, 200000.0, 200000.0,
               50, 50, True, 1, 1.0, 1.0, (0, 0, 1))

        entity = sceneManager.createEntity('floor', 'FloorPlane')
        entity.setMaterialName('Examples/RustySteel')
        sceneManager.rootSceneNode.createChildSceneNode().attachObject(entity)

        # create head entity
        headNode = sceneManager.rootSceneNode.createChildSceneNode()
        entity = sceneManager.createEntity('head', 'ogrehead.mesh')
        headNode.attachObject(entity)

        # make sure the camera track this node
        self.camera.setAutoTracking(True, headNode)

        # create the camera node & attach camera
        cameraNode = sceneManager.rootSceneNode.createChildSceneNode()
        cameraNode.attachObject(self.camera)

        # set up spline animation of node
        animation = sceneManager.createAnimation('CameraTrack', 10)
        animation.interpolationMode = ogre.Animation.IM_SPLINE
        
        animationTrack = animation.createTrack(0, cameraNode)
        
        key = animationTrack.createKeyFrame(0)
        
        key = animationTrack.createKeyFrame(2.5)
        key.translation = 500.0, 500.0, -1000.0
        
        key = animationTrack.createKeyFrame(5)
        key.translation = -1500.0, -1500.0, -600.0
        
        key = animationTrack.createKeyFrame(7.5)
        key.translation = 0.0, -100.0, 0.0
        
        key = animationTrack.createKeyFrame(10.0)
        key.translation = 0.0, 0.0, 0.0

        self.animationState = sceneManager.createAnimationState('CameraTrack')
        self.animationState.enabled = True

        # add some fog
        sceneManager.setFog(ogre.FOG_EXP, (1, 1, 1), 0.0002)

    def _createFrameListener(self):
        self.frameListener = CameraTrackListener(self.renderWindow, self.camera, self.animationState)
        self.root.addFrameListener(self.frameListener)

class CameraTrackListener(sf.FrameListener):
    def __init__(self, renderWindow, camera, animationState):
        sf.FrameListener.__init__(self, renderWindow, camera)
        self.animationState = animationState

    def frameStarted(self, frameEvent):
        self.animationState.addTime(frameEvent.timeSinceLastFrame)
        return sf.FrameListener.frameStarted(self, frameEvent)

if __name__ == '__main__':
    try:
        application = CameraTrackApplication()
        application.go()
    except ogre.OgreException, e:
        print e
    
