## This code is in the Public Domain

## This currently only works with wx 2.5!
## If you are using wx 2.4, comment out the MainLoop function.
import wx, sys
from wx import Frame
import pyogre.ogre as ogre
import time

class MyFrame(wx.Frame):
    def __init__(
            self, parent, ID, title, pos=wx.DefaultPosition,
            size=wx.DefaultSize, style=wx.DEFAULT_FRAME_STYLE
           ):
        size = wx.Size(800,600)
        wx.Frame.__init__(self, parent, ID, title, pos, size, style)
        self.Bind(wx.EVT_CLOSE, self.OnCloseWindow)
        self.Bind(wx.EVT_ERASE_BACKGROUND, self.OnEraseBackground)
        self.Bind(wx.EVT_SIZE, self.OnSize)

    def OnSize(self, event):
        size = self.GetClientSize()
        print 'resizing', size
        if getattr(self, 'app', None):
            self.app.update()
        event.Skip()

    def OnEraseBackground(self, event):
        pass # Do nothing, to avoid flashing on MSW.

    def OnCloseMe(self, event):
        self.Close(True)

    def OnCloseWindow(self, event):
        self.Destroy()

class App(wx.App):
    """Application class."""

    def OnInit(self):
        self.frame = MyFrame(None, -1, 'PopupButton Test')
        self.frame.Show()
        self.SetTopWindow(self.frame)
        return True

    def initializeOgre(self):    
        root = ogre.Root(ogre.getPluginPath())
        self.root = root

        # setup resources
        config = ogre.ConfigFile()
        config.loadFromFile('resources.cfg')
        for section, key, path in config.values:
            ogre.ResourceGroupManager.getSingleton().addResourceLocation(path, key, section)            

        #configure
        carryOn = root.showConfigDialog()
        if not carryOn:
            sys.exit('Quit from Config Dialog') 

        root.initialise(False)
        renderParameters = ogre._StringStringMap()
        renderParameters['externalWindowHandle'] = str(self.frame.GetHandle())
        renderWindow = root.createRenderWindow('TestOgre render window', 640,
                                               480, False, renderParameters)

        ogre.ResourceGroupManager.getSingleton().initialiseAllResourceGroups()

        # chooseSceneManager
        sceneManager = root.getSceneManager(ogre.ST_GENERIC)

        # createCamera
        camera = sceneManager.createCamera('PlayerCam')
        camera.position = (0, 0, 500)
        camera.lookAt(ogre.Vector3(0, 0, -300))
        camera.nearClipDistance = 5

        # createViewports
        viewport = renderWindow.addViewport(camera, 0, 0.0, 0.0, 1.0, 1.0)
        viewport.backgroundColour = 0, 0, 0

        # set mipmaps ignored...

        # create scene
        sceneManager.ambientLight = 0.2, 0.2, 0.2
        sceneManager.setSkyDome(True, 'Examples/CloudySky', 4.0, 8.0)

        light = sceneManager.createLight('MainLight')
        light.position = (20, 80, 50)

        plane = ogre.Plane()
        plane.normal = ogre.Vector3(0, 1, 0)
        plane.d = 200
        ogre.MeshManager.getSingleton().createPlane('FloorPlane', "General",
                                                    plane, 200000, 200000,
                                                    20, 20, True, 1, 50, 50,
                                                    (0, 0, 1))

        # create floor entity
        entity = sceneManager.createEntity('floor', 'FloorPlane')
        entity.setMaterialName('Examples/RustySteel')
        sceneManager.rootSceneNode.createChildSceneNode().attachObject(entity)

        # create head entity
        headNode = sceneManager.rootSceneNode.createChildSceneNode()
        entity = sceneManager.createEntity('head', 'ogrehead.mesh')
        headNode.attachObject(entity)

        # make sure the camera track this node
        camera.setAutoTracking(True, headNode)

        # create the camera node & attach camera
        cameraNode = sceneManager.rootSceneNode.createChildSceneNode()
        cameraNode.attachObject(camera)

        # set up spline animation of node
        animation = sceneManager.createAnimation('CameraTrack', 10)
        animation.interpolationMode = ogre.Animation.IM_SPLINE
        animationTrack = animation.createTrack(0, cameraNode)
        key = animationTrack.createKeyFrame(0)
        key = animationTrack.createKeyFrame(2.5)
        key.translation = (500.0, 500.0, -1000.0)
        key = animationTrack.createKeyFrame(5)
        key.translation = (-1500.0, -1500.0, -600.0)
        key = animationTrack.createKeyFrame(7.5)
        key.translation = (0.0, -100.0, 0.0)
        key = animationTrack.createKeyFrame(10.0)
        key.translation = (0.0, 0.0, 0.0)
        animationState = sceneManager.createAnimationState('CameraTrack')
        animationState.enabled = True

        # add some fog
        sceneManager.setFog(ogre.FOG_EXP, ogre.ColourValue.White, 0.0002)
        self.frame.app = self
        
        renderWindow.active = True
        self.update()

    def update(self):
        self.root.renderOneFrame()

    def MainLoop(self):
        self.keepGoing = True
        evtloop = wx.EventLoop()
        old = wx.EventLoop.GetActive()
        wx.EventLoop.SetActive(evtloop)
        
        while self.keepGoing:
            self.update()

            while evtloop.Pending():
                evtloop.Dispatch()

            time.sleep(0.10)
            self.ProcessIdle()

            while self.Pending():
                self.Dispatch()
            self.update()

def main():
    try:
        app = App()
        app.initializeOgre()
        app.MainLoop()
    except ogre.OgreException, e:
        print e

if __name__ == '__main__':
    main()
