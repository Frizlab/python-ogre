# This code is in the Public Domain
import pyogre.ogre as ogre
import SampleFramework as sf

class LightingApplication(sf.Application):
    def _createScene(self):
        sceneManager = self.sceneManager
        camera = self.camera
        
        sceneManager.ambientLight = 0.1, 0.1, 0.1
        sceneManager.setSkyBox(True, 'Examples/SpaceSkyBox')

        entity = sceneManager.createEntity('head', 'ogrehead.mesh')
        sceneManager.rootSceneNode.attachObject(entity)

        redYellowLightsNode = sceneManager.rootSceneNode.createChildSceneNode()
        redYellowLights = sceneManager.createBillboardSet('RedYellowLights', 20)
        redYellowLights.materialName = 'Examples/Flare'
        redYellowLightsNode.attachObject(redYellowLights)
        self.redYellowLightsNode = redYellowLightsNode

        greenBlueLightsNode = sceneManager.rootSceneNode.createChildSceneNode()
        greenBlueLights = sceneManager.createBillboardSet('GreenBlueLights', 20)
        greenBlueLights.materialName = 'Examples/Flare'
        greenBlueLightsNode.attachObject(greenBlueLights)
        self.greenBlueLightsNode = greenBlueLightsNode

        # Red light billboard, in "off" state
        redLightPosition = 78, -8, -70
        redLightBoard = redYellowLights.createBillboard(redLightPosition, (1, 1, 1))
        redLightBoard.colour = 0, 0, 0
        
        # Blue light billboard, in "off" state        
        blueLightPosition = -90, -8, -70
        blueLightBoard = greenBlueLights.createBillboard(blueLightPosition, (1, 1, 1))
        blueLightBoard.colour = 0, 0, 0
        
        # Yellow light billboard, in "off" state        
        yellowLightPosition = -4.5, 30, -80
        yellowLightBoard = redYellowLights.createBillboard(yellowLightPosition, (1, 1, 1))
        yellowLightBoard.colour = 0, 0, 0
        
        # Green light billboard, in "off" state        
        greenLightPosition = 50, 70, 80
        greenLightBoard = redYellowLights.createBillboard(greenLightPosition, (1, 1, 1))
        greenLightBoard.colour = 0, 0, 0

        # Red light, in "off" state
        redLight = sceneManager.createLight('RedFlyingLight')
        redLight.type = ogre.Light.LT_POINT
        redLight.position = redLightPosition
        redLight.diffuseColour = 0, 0, 0
        redYellowLightsNode.attachObject(redLight)

        # Blue light, in "off" state
        blueLight = sceneManager.createLight('BlueFlyingLight')
        blueLight.type = ogre.Light.LT_POINT
        blueLight.position = blueLightPosition
        blueLight.diffuseColour = 0, 0, 0
        greenBlueLightsNode.attachObject(blueLight)

        # Yellow light, in "off" state
        yellowLight = sceneManager.createLight('YellowFlyingLight')
        yellowLight.type = ogre.Light.LT_POINT
        yellowLight.position = yellowLightPosition
        yellowLight.diffuseColour = 0, 0, 0
        redYellowLightsNode.attachObject(yellowLight)

        # Green light, in "off" state
        greenLight = sceneManager.createLight('GreenFlyingLight')
        greenLight.type = ogre.Light.LT_POINT
        greenLight.position = greenLightPosition
        greenLight.diffuseColour = 0, 0, 0
        greenBlueLightsNode.attachObject(greenLight)
        
        # Light flashers
        redLightFlasher = LightFlasher(redLight, redLightBoard, (1, 0, 0))
        greenLightFlasher = LightFlasher(greenLight, greenLightBoard, (0, 1, 0))
        blueLightFlasher = LightFlasher(blueLight, blueLightBoard, (0, 0, 1))
        yellowLightFlasher = LightFlasher(yellowLight, yellowLightBoard, (1.0,1.0,0.0))
        
        # Light controller functions
        redLightControllerFunc = LightFlasherControllerFunction(ogre.WFT_SINE, 0.5, 0.0)
        blueLightControllerFunc = LightFlasherControllerFunction(ogre.WFT_SINE, 0.75, 0.5)
        yellowLightControllerFunc = LightFlasherControllerFunction(ogre.WFT_SINE, 0.25, 0.0)
        greenLightControllerFunc = LightFlasherControllerFunction(ogre.WFT_SINE, 0.25, 0.5)

        # Convert to shared pointers
        redLightFlasher = ogre.SharedPtr(redLightFlasher)
        greenLightFlasher = ogre.SharedPtr(greenLightFlasher)
        blueLightFlasher = ogre.SharedPtr(blueLightFlasher)
        yellowLightFlasher = ogre.SharedPtr(yellowLightFlasher)
        
        redLightControllerFunc = ogre.SharedPtr(redLightControllerFunc)
        blueLightControllerFunc = ogre.SharedPtr(blueLightControllerFunc)
        yellowLightControllerFunc = ogre.SharedPtr(yellowLightControllerFunc)
        greenLightControllerFunc = ogre.SharedPtr(greenLightControllerFunc)

        # Light controllers
        controllerManager = ogre.ControllerManager.getSingleton()
        self.redLightController = controllerManager.createController(
            controllerManager.getFrameTimeSource(),
            redLightFlasher,
            redLightControllerFunc)
        self.blueLightController = controllerManager.createController(
            controllerManager.getFrameTimeSource(),
            blueLightFlasher,
            blueLightControllerFunc)
        self.yellowLightController = controllerManager.createController(
            controllerManager.getFrameTimeSource(),
            yellowLightFlasher,
            yellowLightControllerFunc)
        self.greenLightController = controllerManager.createController(
            controllerManager.getFrameTimeSource(),
            greenLightFlasher,
            greenLightControllerFunc)
        
    def _createFrameListener(self):
        self.frameListener = LightingListener(self.renderWindow, self.camera,
                                               self.redYellowLightsNode, self.greenBlueLightsNode )
        self.root.addFrameListener(self.frameListener)

class LightingListener(sf.FrameListener):
    def __init__(self, renderWindow, camera, redYellowLightsNode, greenBlueLightsNode):
        sf.FrameListener.__init__(self, renderWindow, camera)
        self.redYellowLightsNode = redYellowLightsNode
        self.greenBlueLightsNode = greenBlueLightsNode

    def frameStarted(self, frameEvent):
        self.redYellowLightsNode.yaw(ogre.Degree(frameEvent.timeSinceLastFrame * 10.0),
                                      ogre.Node.TS_LOCAL)
        self.greenBlueLightsNode.pitch(ogre.Degree(frameEvent.timeSinceLastFrame * 20.0),
                                        ogre.Node.TS_LOCAL)
        return sf.FrameListener.frameStarted(self, frameEvent)

class LightFlasherControllerFunction(ogre.WaveformControllerFunction):
    def __init__(self, waveType, frequency, phase):
        ogre.WaveformControllerFunction.__init__(
            self, waveType, 0, frequency, phase, 1, True)

class LightFlasher(ogre.RealControllerValue):
    def __init__(self, light, billboard, maxColour):
        ogre.RealControllerValue.__init__(self)
        self.light = light
        self.billboard = billboard
        self.maxColour = ogre.ColourValue(maxColour)
        self.intensity = 0.0

    def getValue(self):
        return self.intensity

    def setValue(self, value):
        self.intensity = value

        newColour = self.maxColour * value
        newColour.a = self.maxColour.a

        self.light.diffuseColour = newColour
        self.billboard.colour = newColour
        

if __name__ == '__main__':
    try:
        application = LightingApplication()
        application.go()
    except ogre.OgreException, e:
        print e
