# This code is in the Public Domain
import pyogre.ogre as ogre
import SampleFramework as sf

class ParticleApplication(sf.Application):
    def _createScene(self):
        sceneManager = self.sceneManager
        camera = self.camera
        
        sceneManager.ambientLight = (0.5, 0.5, 0.5)

        entity = sceneManager.createEntity('head', 'ogrehead.mesh')
        entity.setMaterialName('Examples/EnvMappedRustySteel')

        sceneManager.rootSceneNode.createChildSceneNode().attachObject(entity)

        particleSystemManager = ogre.ParticleSystemManager.getSingleton()
        particleSystem1 = particleSystemManager.createSystem('Nimbus', 'Examples/GreenyNimbus')
        sceneManager.rootSceneNode.createChildSceneNode().attachObject(particleSystem1)

        self.fountainNode = sceneManager.rootSceneNode.createChildSceneNode()

        particleSystem2 = particleSystemManager.createSystem('fountain1', 'Examples/PurpleFountain')
        node = self.fountainNode.createChildSceneNode()
        node.translate(200, -100, 0)
        node.rotate((0, 0, -1), ogre.Radian(ogre.Degree(20)))
        node.attachObject(particleSystem2)

        particleSystem3 = particleSystemManager.createSystem('fountain2', 'Examples/PurpleFountain')
        node = self.fountainNode.createChildSceneNode()
        node.translate(-200, -100, 0)
        node.rotate((0, 0, -1), ogre.Radian(ogre.Degree(-20)))
        node.attachObject(particleSystem3)

        particleSystem4 = particleSystemManager.createSystem('rain', 'Examples/Rain')
        node = sceneManager.rootSceneNode.createChildSceneNode()
        node.translate(0, 1000, 0)
        node.attachObject(particleSystem4)
        particleSystem4.fastForward(5)

    def _createFrameListener(self):
        self.frameListener = ParticleListener(self.renderWindow, self.camera, self.fountainNode)
        self.root.addFrameListener(self.frameListener)

class ParticleListener(sf.FrameListener):
    def __init__(self, renderWindow, camera, fountainNode):
        sf.FrameListener.__init__(self, renderWindow, camera)
        self.fountainNode = fountainNode

    def frameStarted(self, frameEvent):
        self.fountainNode.yaw(ogre.Radian(ogre.Degree(frameEvent.timeSinceLastFrame * 30.0)))
        return sf.FrameListener.frameStarted(self, frameEvent)

if __name__ == '__main__':
    try:
        application = ParticleApplication()
        application.go()
    except ogre.OgreException, e:
        print e
