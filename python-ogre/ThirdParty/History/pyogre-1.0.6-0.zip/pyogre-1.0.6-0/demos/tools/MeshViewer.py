#  Python CEGUI MeshViewer Demo
#-----------------------------------------------------------------------------
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
# See the
# *  GNU General Public License for more details.
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

#  The demo is based on the original demo by Pablo D. Buiras, details as follows:
#      Mon Feb 28 14:00:43 2005
#      Copyright 2005  Pablo D. Buiras
#      pablobuiras@users.sourceforge.net

#  Known issues:
#        - animation states taken from skeleton, should be entity
#        - animation state not cleared when changing animation states within an entity
#        - problems rotate/translate and selecting gui sliders
#        - sort out cursor when moving entity
#
#----------------------------------------

from pyogre import ogre,cegui
import SampleFramework

class CEGUIFrameListener(SampleFramework.FrameListener):

    def __init__(self, renderWindow, camera, sceneManager):

        self.speed = 0.5                  # Animation Speed

        self.keepRendering = True         # Flag to continue rendering
        self.AnimationState= None         # Current Animation State
        self.hasAnimationState= False     # entity has Animation State

        self.m_entity = None              # Entity
        self.m_node = None                # Scenenode

        self.allow_rotationX = False      # Allow rotation X axis
        self.allow_rotationY = False      # Allow rotation Y axis
        self.allow_rotationZ = False      # Allow rotation Z axis
        self.allow_translation = False    # Allow Translations

        self.connections=[]               # connections
        self.meshes=[]                    # mesh list items
        self.animations=[]                # animation list items

        self.numScreenShots=0

        SampleFramework.FrameListener.__init__(self, renderWindow, camera)

	self.sceneManager = sceneManager
        # load mesh list
        self.loadMesList()                # load mesh list
       

    def _setupInput(self):
        self.eventProcessor = ogre.EventProcessor()
        self.eventProcessor.initialise(self.renderWindow)
        self.eventProcessor.startProcessingEvents()

        # register as a listener for events
        self.eventProcessor.addKeyListener(self)
        self.eventProcessor.addMouseListener(self)
        self.eventProcessor.addMouseMotionListener(self)

        # get controls for event handling
        combo = cegui.WindowManager.getSingleton().getWindow("MeshViewer/MainWindow/MeshBox")
        stop = cegui.WindowManager.getSingleton().getWindow("MeshViewer/MainWindow/AnimStop")
        play = cegui.WindowManager.getSingleton().getWindow("MeshViewer/MainWindow/AnimPlay")
        scroll = cegui.WindowManager.getSingleton().getWindow("MeshViewer/MainWindow/AnimSpeed")
        list = cegui.WindowManager.getSingleton().getWindow("MeshViewer/MainWindow/AnimList")
        rotateX = cegui.WindowManager.getSingleton().getWindow("MeshViewer/RotateX")
        rotateY = cegui.WindowManager.getSingleton().getWindow("MeshViewer/RotateY")
        rotateZ = cegui.WindowManager.getSingleton().getWindow("MeshViewer/RotateZ")
        translate = cegui.WindowManager.getSingleton().getWindow("MeshViewer/Translate")
        printButton = cegui.WindowManager.getSingleton().getWindow("MeshViewer/Print")

        # create events
        try:
            self.connections.append(combo.subscribeEvent(combo.EventListSelectionAccepted,self.onSelectMesh))
            self.connections.append(stop.subscribeEvent(stop.EventClicked,self.onStopAnim))
            self.connections.append(play.subscribeEvent(play.EventClicked,self.onPlayAnim))
            self.connections.append(scroll.subscribeEvent(scroll.EventThumbTrackEnded, self.onSetScrollSpeed))
            self.connections.append(list.subscribeEvent(list.EventSelectionChanged, self.onSelectAnimation))
            self.connections.append(rotateX.subscribeEvent(rotateX.EventCheckStateChanged, self.onEnableRotation))
            self.connections.append(rotateY.subscribeEvent(rotateY.EventCheckStateChanged, self.onEnableRotation))
            self.connections.append(rotateZ.subscribeEvent(rotateZ.EventCheckStateChanged, self.onEnableRotation))
            self.connections.append(translate.subscribeEvent(translate.EventCheckStateChanged, self.onEnableRotation))
            self.connections.append(printButton.subscribeEvent(printButton.EventClicked, self.onPrintScreen))
        except:
            print "Error Creating Events"

    # do our own cleaning up
    def cleanUp(self):
        try:
            # disconnect events that we created in listener to avoid memory leaks
            for i in range(len(self.connections)):
                c = self.connections[i]
                c.disconnect    

            # clear out listitems to avoid memory leaks
            combo = cegui.WindowManager.getSingleton().getWindow("MeshViewer/MainWindow/MeshBox")
            list = cegui.WindowManager.getSingleton().getWindow("MeshViewer/MainWindow/AnimList")
            combo.resetList() 
            list.resetList()  
            del self.meshes            # mesh list items
            del self.animations        # animation list items
        except:
            print "Oops Error Cleaning up Bad "

    def isMouseGUI(self):
        # get window mouse cureently is in
        win_mouse = cegui.System.getSingleton().windowContainingMouse
        # defualt window is where mesh is displayed
 	if (win_mouse):
            if (win_mouse.type=="DefaultWindow"): return False
        return True

    def frameStarted(self, evt):
	self.update(evt.timeSinceLastFrame)
        return self.keepRendering

    def mouseDragged(self, evt):
        # check if mouse drag on gui element
        if (self.isMouseGUI()):                        
            self.mouseMoved(evt)                        
        else:
            # rotate / translate scnenode
	    self.translate(evt.relX*100, -evt.relY*100, 0) 
	    self.rotate(evt.relX*300,evt.relY*300,evt.relZ*300)

    def mousePressed(self, evt):
        button = self._convertOgreButtonToCegui(evt)
        cegui.System.getSingleton().injectMouseButtonDown(button)
        win = cegui.System.getSingleton().windowContainingMouse

    def mouseReleased(self, evt):
        button = self._convertOgreButtonToCegui(evt)
        cegui.System.getSingleton().injectMouseButtonUp(button)
	
    def mouseClicked(self, evt):
        pass

    def mouseEntered(self, evt):
        pass

    def mouseExited(self, evt):
        pass

    def mouseMoved(self, evt):
        system = cegui.System.getSingleton()
        renderer = system.renderer
        system.injectMouseMove(evt.relX * renderer.width,
                               evt.relY * renderer.height)


    def keyPressed(self, evt):
        if evt.key == ogre.KC_ESCAPE:
            self.keepRendering = False
            self.cleanUp()   # do our own clean up

        system = cegui.System.getSingleton()
        system.injectKeyDown(evt.key)
        system.injectChar(evt.keyChar)
        evt.consume()

    def keyReleased(self, evt):
        system = cegui.System.getSingleton()
        system.injectKeyUp(evt.key)

    def keyClicked(self, evt):
        pass

    def _convertOgreButtonToCegui(self,evt):
	# Convert ogre button to cegui button
        if (evt.buttonID & ogre.MouseEvent.BUTTON0_MASK):
            return cegui.LeftButton	
            print "Left Button"
        elif (evt.buttonID & ogre.MouseEvent.BUTTON1_MASK):
            return cegui.RightButton	
        elif (evt.buttonID & ogre.MouseEvent.BUTTON2_MASK):
            return cegui.MiddleButton
        elif (evt.buttonID & ogre.MouseEvent.BUTTON3_MASK):
            return cegui.X1Button
        return cegui.LeftButton


    #  animation selected from animation list box
    def onSelectAnimation(self,args):
        try:
            listbox = args.window                        # get listbox Window 
            if (listbox.selectedCount):                  # any animations
                self.initAnimation()                     # initialise
                t=listbox.getFirstSelectedItem().text    # get first selected item  

                # set selected animation state
                self.AnimationState=self.m_entity.getAnimationState(t)
                self.hasAnimationState = True
                self.changeAnimationState(True)
        except:
            print "Error Selecting Animation"

    #  update animation
    def update(self, delta):
       if (self.hasAnimationState): 
           if (self.AnimationState.enabled): 
              self.AnimationState.addTime(self.speed*delta)   
     
    # Event Handles Mesh Combo Box Selection
    def onSelectMesh(self,args):
        try:
            if (args.window.text):                          # combo selected text
                self.loadMesh(args.window.text)             # load the entity/scenenode
                self.loadAnimations()                       # load animations for entity
        except:
            print "Error Selecting Mesh"
  
 
    # Load animations for a node
    def loadAnimations(self):
	listbox = cegui.WindowManager.getSingleton().getWindow("MeshViewer/MainWindow/AnimList")
        try:
            # initialise
	    listbox.resetList()
            self.animations=[]
            self.hasAnimationState = False
            self.initAnimation()

            # get a list of animations associated with the entity
            if (self.m_entity.skeleton):
                skel = self.m_entity.skeleton
                animations = [ skel.getAnimation(j).name for j in range(skel.numAnimations) ]
                # add animation names to listbox
                for i, v in enumerate(animations):
            	    item = cegui.ListboxTextItem(v,i)
            	    item.selectionColours=cegui.colour(1.0, 0.0, 0.0, 1.0)
            	    item.selectionBrushImage=("TaharezLook", "ListboxSelectionBrush")
            	    listbox.addItem(item)
            	    item.thisown = 0
                    # keep reference to item whilst combo uses
                    self.animations.append(item)

            # enable/disable anim play/stop buttons
            cegui.WindowManager.getSingleton().getWindow("MeshViewer/MainWindow/AnimStop").enabled=(listbox.itemCount>0)
            cegui.WindowManager.getSingleton().getWindow("MeshViewer/MainWindow/AnimPlay").enabled=(listbox.itemCount>0)
        except:
            print "Error Loading Animations"


    # initialise animation
    def initAnimation(self):
        try:
            self.hasAnimationState = False
            self.changeAnimationState(False)
            # initialise speed bar
            win=cegui.WindowManager.getSingleton().getWindow("MeshViewer/MainWindow/AnimSpeed")
            win.documentSize=20
            win.scrollPosition=10
            max = (win.documentSize)/2
            self.speed = (win.scrollPosition/max)
        except:
            print "Error Initialising Animation"

    # load meshes in combo
    def loadMesList(self):
        try:
            red  = cegui.colour(1.0, 0.0, 0.0, 0.5)
            # get list meshes 
            meshList = ogre.ResourceGroupManager.getSingleton().findResourceNames("General", "*.mesh")
            iterator = meshList.get()
            meshes = [ iterator.__getitem__(j) for j in range(iterator.size()) ]
            listbox = cegui.WindowManager.getSingleton().getWindow("MeshViewer/MainWindow/MeshBox")
            # iterate through list and add to combo
            for i, v in enumerate(meshes):
                item = cegui.ListboxTextItem(v,i)
                item.selectionColours=red
                item.selectionBrushImage=("TaharezLook", "ListboxSelectionBrush")
                listbox.addItem(item)
                # keep reference to item whilst listbox uses
                self.meshes.append(item)
                item.thisown = 0
        except:
            print "Error Loading Mesh List"
            

    # Load mesh for display
    def loadMesh(self, mesh_name):
        try:
            # mesh selected
	    if (len(mesh_name)==0): return
            # get rid of current mesh
            if (self.m_entity):
                self.m_node.detachObject(self.m_entity)
                self.sceneManager.removeEntity(self.m_entity)
            # create entity
            self.m_node = self.sceneManager.rootSceneNode.createChildSceneNode()
            self.m_entity = self.sceneManager.createEntity('entity', mesh_name)
            self.m_node.attachObject(self.m_entity)
            self.m_node.resetOrientation()
            self.m_node.position = ogre.Vector3(0,0,0)

            realCentre = ogre.Vector3(self.m_entity.boundingBox.getCenter())
            rad = self.m_entity.boundingRadius

            self.camera.position = ogre.Vector3(0, rad*2, rad*2)
            self.camera.lookAt(realCentre)
            self.camera.moveRelative(ogre.Vector3(rad / 2.0,0,0))
        except:
            print "Error Creating Entity"

    # events
    def changeAnimationState(self,state):
        try:
            # does an animation exist   
            if (self.hasAnimationState):
                # if animation running stop   
                if (self.AnimationState.enabled):
                    self.AnimationState.enabled = False
                    self.AnimationState.loop = False
                # enable animation    
                if (state):
                    self.AnimationState.enabled = True
                    self.AnimationState.loop = True
        except:
            print "Error Change Animations State"

    # event handling anim stop button
    def onStopAnim(self,args):
        self.changeAnimationState(False)

    # event handling anim play button
    def onPlayAnim(self,args):
        self.changeAnimationState(True)

    # print screen
    def onPrintScreen(self,args):
        try:
            path = 'screenshot_%d.png' % self.numScreenShots
            self.numScreenShots += 1
            self.renderWindow.writeContentsToFile(path)
            self.renderWindow.debugText = 'screenshot taken: ' + path
        except:
            print "Print Screen Error"

    # scroll speed event handling
    def onSetScrollSpeed(self,args):
        try:
	    win = args.window
            #win.scrollPosition (0 to 10 documentSize)
            max = (win.documentSize)/2
            self.speed = (win.scrollPosition/max)
        except:
            print "Error Setting Scrool Speed"
        
    # rotation / translation selection events
    def onEnableRotation(self,args):
        try:
            if (args.window.name=="MeshViewer/RotateX"):
                self.allow_rotationX = args.window.selected
            if (args.window.name=="MeshViewer/RotateY"):
                self.allow_rotationY = args.window.selected
            if (args.window.name=="MeshViewer/RotateZ"):
                self.allow_rotationZ = args.window.selected
            if (args.window.name=="MeshViewer/Translate"):
                self.allow_translation = args.window.selected
        except:
            print "Error Setting Translation/Rotation"

    # translate entity
    def translate(self,x,y,z):
        try:
            if not self.m_node: return 
            if (self.allow_translation):
                self.m_node.translate(ogre.Vector3(x, y,z))
        except:
            print "Error Translating"

    # rotate entity
    def rotate(self,x,y,z):
        try:
            if not self.m_node: return 
            deltaq=ogre.Quaternion()
            vec = ogre.Vector3()

            if (self.allow_rotationX):
                deltaq.FromAngleAxis(ogre.Degree(x), vec.UNIT_X)
                self.m_node.rotate(deltaq)
            if (self.allow_rotationY):
                deltaq.FromAngleAxis(ogre.Degree(y), vec.UNIT_Y)
                self.m_node.rotate(deltaq)
            if (self.allow_rotationZ):
                deltaq.FromAngleAxis(ogre.Degree(z), vec.UNIT_Z)
            self.m_node.rotate(deltaq)
        except:
            print "Error Rotating"
    
class GEUIApplication(SampleFramework.Application):

    def __init__(self):
        SampleFramework.Application.__init__(self)
        self.guiRenderer=0
        self.system =0

    def _createGUI(self):

        # Initiaslise CEGUI Renderer
        self.guiRenderer = cegui.OgreCEGUIRenderer(self.renderWindow)
        self.system = cegui.System(self.guiRenderer)
        cegui.Logger.getSingleton().loggingLevel = cegui.Insane

        # Load Cegui Scheme
        cegui.SchemeManager.getSingleton().loadScheme("TaharezLook.scheme")
        self.system.defaultMouseCursor=("TaharezLook", "MouseArrow")
        cegui.FontManager.getSingleton().createFont("tahoma-12.font")

        # Load Layout (from media/gui/datafiles/layout)
        sheet = cegui.WindowManager.getSingleton().loadWindowLayout("meshviewer.layout")
        self.system.guiSheet = sheet


    def _createScene(self):
        sceneManager = self.sceneManager
        sceneManager.ambientLight = 0.20, 0.20, 0.20

        light = sceneManager.createLight('MainLight')
        light.position = 20, 80, 50
        self.viewport.backgroundColour = ogre.ColourValue(0.6,0.6,0.6)
        self._createGUI()


    def _createCamera(self):
        self.camera = self.sceneManager.createCamera("PlayerCam")
        self.camera.nearClipDistance = 5

    def _createFrameListener(self):
        self.frameListener = CEGUIFrameListener(self.renderWindow, self.camera, self.sceneManager)
        self.root.addFrameListener(self.frameListener)
        self.frameListener.showDebugOverlay(False)

    def __del__(self):
        "Clear variables, this is needed to ensure the correct order of deletion"
        del self.camera
        del self.sceneManager
        del self.frameListener
        del self.system
        del self.guiRenderer
        del self.root
        del self.renderWindow        
     

if __name__ == '__main__':
    try:
        ta = GEUIApplication()
        ta.go()
    except ogre.OgreException, e:
        print e
