#include "PythonException.h"

PythonException::PythonException(const char *type, const char *value, const char *trace)
{
    if (type)
        mType = type;

    if (value)
        mValue = value;

    if (trace)
        mTrace = trace;

    mToString = mType + ": " + mValue + "\n" + mTrace;
}

