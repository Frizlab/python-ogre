#include "PyOgre.h"

void pyOgreFinal()
{
    Py_Finalize();
} // pyOgreFinal()

void pyOgreInit()
{
    Py_Initialize();
    init_ogre();

} // pyOgreInit


PythonException pyOgreException()
{
    PyObject *errType = 0,
             *errValue = 0,
             *errTrace = 0;

    PyObject *strType = 0,
             *strValue = 0,
             *strTrace = 0;

    char *type = 0,
         *value = 0,
         *trace = 0;

    PyErr_Fetch(&errType, &errValue, &errTrace);

    if (errType)
    {
        strType = PyObject_Str(errType);
        type = PyString_AsString(strType);
    } // if

    if (errValue)
    {
        strValue = PyObject_Str(errValue);
        value = PyString_AsString(strValue);
    } // if

    if (errTrace)
    {
        strTrace = PyObject_Str(errTrace);
        trace = PyString_AsString(strTrace);
    } // if

    PythonException toReturn(type, value, trace);


    Py_XDECREF(strType);
    Py_XDECREF(strValue);
    Py_XDECREF(strTrace);
    Py_XDECREF(errType);
    Py_XDECREF(errValue);
    Py_XDECREF(errTrace);

    return toReturn;
}
