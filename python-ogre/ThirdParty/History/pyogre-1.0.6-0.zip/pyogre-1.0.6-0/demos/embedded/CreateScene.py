import ogre

def createScene():
    sceneManager = ogre.Root.getSingleton().getSceneManager(ogre.ST_GENERIC)
    sceneManager.ambientLight = (0.5, 0.5, 0.5)

    light = sceneManager.createLight('MainLight')
    light.position = (20, 80, 50)

    planeEntity = sceneManager.createEntity('Plane', ogre.SceneManager.PT_PLANE)
    planeEntity.setMaterialName('Examples/BumpyMetal')

    knotEntity = sceneManager.createEntity('Knot', 'knot.mesh')
    knotEntity.setMaterialName('Examples/TransparentTest')

    
    rootNode = sceneManager.rootSceneNode
    rootNode.attachObject(planeEntity)
    rootNode.attachObject(knotEntity)

    for index in xrange(0,10):
        node = sceneManager.createSceneNode()
        nodePos = ogre.Vector3()
        nodePos.x = ogre.Math.SymmetricRandom() * 500.0
        nodePos.y = ogre.Math.SymmetricRandom() * 500.0
        nodePos.z = ogre.Math.SymmetricRandom() * 500.0
        node.position = nodePos
        rootNode.addChild(node)
        knotEntityClone = knotEntity.clone('Knot%d' % index )
        node.attachObject(knotEntityClone)

createScene()
