#include "ExampleApplication.h"
#include "PyOgre.h"
#include <Python.h>

#include <stdio.h>

class EmbeddedApplication : public ExampleApplication
{
public:
    virtual void createScene(void)
    {
        PyObject *dict = PyModule_GetDict(PyImport_AddModule("__main__"));

        FILE *file = fopen("CreateScene.py", "r");
        PyRun_File(file, "CreateScene.py", Py_file_input, dict, 0);

        if (PyErr_Occurred())
            OGRE_EXCEPT(412, pyOgreException().toString().c_str(), "EmbeddedApplication::createScene");
    }

    virtual void createFrameListener(void)
    {
        PyObject *dict;

        dict = PyModule_GetDict(PyImport_AddModule("__main__"));

        FILE *file = fopen("FrameListener.py", "r");
        PyRun_File(file, "FrameListener.py", Py_file_input, dict, 0);

        if (PyErr_Occurred())
            OGRE_EXCEPT(412, pyOgreException().toString().c_str(), "EmbeddedApplication::createFrameListener");
    }
};
