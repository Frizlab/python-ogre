#ifndef _PythonException_h_
#define _PythonException_h_

#include <Ogre.h>

class PythonException
{
public:
    PythonException(const char *type, const char *value, const char *trace);
    const Ogre::String &getType() {return mType;}
    const Ogre::String &getValue() {return mValue;}
    const Ogre::String &getTrace() {return mTrace;}
    const Ogre::String &toString() {return mToString;}
protected:
    Ogre::String mType, mValue, mTrace, mToString;
};

#endif
