#ifndef _PyOgre_h_
#define _PyOgre_h_

#include "PythonException.h"

#include <Python.h>
#include <Ogre.h>

extern "C"
{
    void init_ogre(void);
}

void pyOgreInit();
void pyOgreFinal();


PythonException pyOgreException();

#endif
