# this code is in the public domain

#-----------------------------------------
#  Demo loading a TaharezLayout (Demo8.LAYOUT from gui\datafiles\layouts)
#
#  Same comments on :  
#     adding list items from within an event, cant see anyother way of doing it
#     Events still dont appear to be returning window etc
#
#
#----------------------------------------

from pyogre import ogre,cegui
import SampleFramework


def _PointHack(x, y):
    return cegui.Vector2(x, y)
cegui.Point = _PointHack


class CEGUIFrameListener(SampleFramework.FrameListener):

    def __init__(self, renderWindow, camera, sceneManager):
        SampleFramework.FrameListener.__init__(self, renderWindow, camera)

        self.keepRendering = True   # whether to continue rendering or not

    def _setupInput(self):
        self.eventProcessor = ogre.EventProcessor()
        self.eventProcessor.initialise(self.renderWindow)
        self.eventProcessor.startProcessingEvents()

        # register as a listener for events
        self.eventProcessor.addKeyListener(self)
        self.eventProcessor.addMouseListener(self)
        self.eventProcessor.addMouseMotionListener(self)

    def frameStarted(self, evt):
        return self.keepRendering

    def mouseDragged(self, evt):
        self.mouseMoved(evt)

    def mousePressed(self, evt):
        button = self._convertOgreButtonToCegui(evt)
        cegui.System.getSingleton().injectMouseButtonDown(button)

    def mouseReleased(self, evt):
        button = self._convertOgreButtonToCegui(evt)
        cegui.System.getSingleton().injectMouseButtonUp(button)
	
    def mouseClicked(self, evt):
        pass

    def mouseEntered(self, evt):
        pass

    def mouseExited(self, evt):
        pass

    def mouseMoved(self, evt):
        system = cegui.System.getSingleton()
        renderer = system.renderer
        system.injectMouseMove(evt.relX * renderer.width,
                               evt.relY * renderer.height)


    def keyPressed(self, evt):
        if evt.key == ogre.KC_ESCAPE:
            self.keepRendering = False
        system = cegui.System.getSingleton()
        system.injectKeyDown(evt.key)
        system.injectChar(evt.keyChar)
        evt.consume()

    def keyReleased(self, evt):
        system = cegui.System.getSingleton()
        system.injectKeyUp(evt.key)

    def keyClicked(self, evt):
        pass

    def _convertOgreButtonToCegui(self,evt):
	# Convert ogre button to cegui button
        if (evt.buttonID & ogre.MouseEvent.BUTTON0_MASK):
            return cegui.LeftButton	
            print "Left Button"
        elif (evt.buttonID & ogre.MouseEvent.BUTTON1_MASK):
            return cegui.RightButton	
        elif (evt.buttonID & ogre.MouseEvent.BUTTON2_MASK):
            return cegui.MiddleButton
        elif (evt.buttonID & ogre.MouseEvent.BUTTON3_MASK):
            return cegui.X1Button
        return cegui.LeftButton


# Event Handling Add Button
def onAdd(args):
    #print `args`
    
    # Get the list box / edit box window
    editBox = cegui.WindowManager.getSingleton().getWindow("Demo8/Window1/Controls/Editbox")
    listBox = cegui.WindowManager.getSingleton().getWindow("Demo8/Window1/Listbox")
   
    # If there's text add to the listbox 
    txt=editBox.text    
    if (len(txt)>0):
        #txt = editBox.text
	#id = listBox.itemCount  
        item = cegui.ListboxTextItem(editBox.text,listBox.itemCount)

	# set the item selection colours and image otherwise you wont see the item
        item.selectionColours = cegui.colour(0.0, 0.0, 1.0, 1.0)
        item.selectionBrushImage = "TaharezLook", "ListboxSelectionBrush"
        # add item to list box
        listBox.addItem(item)
        item.thisown = 0
    editBox.text = ""

    
# Event Handling ColourBar Scroll
def onScrollUpdate(args):

    #print `args`
    # Hack cant seem to get window from event
    # get the scrollbar positions
    r = cegui.WindowManager.getSingleton().getWindow("Demo8/Window1/Controls/Red").scrollPosition
    g = cegui.WindowManager.getSingleton().getWindow("Demo8/Window1/Controls/Green").scrollPosition
    b = cegui.WindowManager.getSingleton().getWindow("Demo8/Window1/Controls/Blue").scrollPosition

    cegui.WindowManager.getSingleton().getWindow("Demo8/Window2/Tips").textColours = cegui.colour(r, g, b, 1.0)

    # Set the Static image colour
    cegui.WindowManager.getSingleton().getWindow("Demo8/Window1/Controls/ColourSample" ).imageColours = cegui.colour(r, g, b, 1.0)
    
# Event Handling Shows message mouse enters text box
def onMouseEnters(args):
    cegui.WindowManager.getSingleton().getWindow("Demo8/Window2/Tips").text="Hello"

def onMouseLeaves(args):
    cegui.WindowManager.getSingleton().getWindow("Demo8/Window2/Tips").text="Goodbye"

    
class GEUIApplication(SampleFramework.Application):

    def __init__(self):
        SampleFramework.Application.__init__(self)
        self.guiRenderer=0
        self.system =0

    def _createGUI(self):

        # Initiaslise CEGUI Renderer
        self.guiRenderer = cegui.OgreCEGUIRenderer(self.renderWindow)
        self.system = cegui.System(self.guiRenderer)
        cegui.Logger.getSingleton().loggingLevel = cegui.Insane

        # Load Cegui Scheme
        cegui.SchemeManager.getSingleton().loadScheme("TaharezLook.scheme")
        self.system.defaultMouseCursor = "TaharezLook", "MouseArrow"
        cegui.FontManager.getSingleton().createFont("tahoma-12.font")

        # Load Layout (from media/gui/datafiles/layout)
        sheet = cegui.WindowManager.getSingleton().loadWindowLayout("Demo8.layout")
        self.system.guiSheet = sheet

        # Get controls
        addButton = cegui.WindowManager.getSingleton().getWindow("Demo8/Window1/Controls/Add")
        redScroll = cegui.WindowManager.getSingleton().getWindow("Demo8/Window1/Controls/Red")
        greenScroll = cegui.WindowManager.getSingleton().getWindow("Demo8/Window1/Controls/Green")
        blueScroll = cegui.WindowManager.getSingleton().getWindow("Demo8/Window1/Controls/Blue")
	
	# Info Panel
        cegui.WindowManager.getSingleton().getWindow("Demo8/Window2/Info").text="An example of Text"

	# Tips Window
        cegui.WindowManager.getSingleton().getWindow("Demo8/Window2/Tips").text="Some Coloured Text"

        # Events
	ec= addButton.subscribeEvent(addButton.EventClicked, onAdd)
	ec2= redScroll.subscribeEvent(redScroll.EventThumbTrackEnded, onScrollUpdate)
	ec3= greenScroll.subscribeEvent(greenScroll.EventThumbTrackEnded, onScrollUpdate)
	ec4= blueScroll.subscribeEvent(blueScroll.EventThumbTrackEnded, onScrollUpdate)
	
    def _createScene(self):
        sceneManager = self.sceneManager
        sceneManager.ambientLight = 0.25, 0.25, 0.25
        self._createGUI()


    def _createCamera(self):
        self.camera = self.sceneManager.createCamera("PlayerCam")
        self.camera.nearClipDistance = 5

    def _createFrameListener(self):
        self.frameListener = CEGUIFrameListener(self.renderWindow, self.camera, self.sceneManager)
        self.root.addFrameListener(self.frameListener)
        self.frameListener.showDebugOverlay(True)

    def __del__(self):
        "Clear variables, this is needed to ensure the correct order of deletion"
        del self.camera
        del self.sceneManager
        del self.frameListener
        del self.system
        del self.guiRenderer
        del self.root
        del self.renderWindow        
     

if __name__ == '__main__':
    try:
        ta = GEUIApplication()
        ta.go()
    except ogre.OgreException, e:
        print e
