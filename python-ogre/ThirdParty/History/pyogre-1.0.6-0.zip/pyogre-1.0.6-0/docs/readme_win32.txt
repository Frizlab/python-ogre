Welcome to PyOgre, a 3D rendering engine for Python.


[Getting Started]
The best place to get started is to go to the PyOgre homepage, and
read the Introduction:
http://www.ogre3d.org/wiki/index.php/PyOgre

There are demos that show off the functionality of PyOgre in the
[python_path]/pyogre/demos folder.  Please note that before you
can run the demos you will need to download the demo media folder
and extract the zip into the [python_path]/pyogre folder.  You can
obtain the media folder from here:
http://developer.berlios.de/project/showfiles.php?group_id=3464

PyOgre also has a few beginner tutorials to start you off.  You can find
the tutorials linked from the PyOgre homepage.  The source code for the
tutorials are also stored in the [python_path]/pyogre/tutorials folder.
(Though the tutorials themselves are on the PyOgre site.)


[Getting Help]

If you have any questions, comments, or any problems you can post them
in the pyogre forum:
http://www.ogre3d.org/phpBB2addons/viewforum.php?f=3

If you would like to submit a bug or patch, you may do so on our
project page: https://developer.berlios.de/projects/pyogre/
You may also submit patches and feature requests on that page.

For specifics on function calls you should refer to Ogre's C++ API reference:
http://www.ogre3d.org/docs/api/html/
However, be sure to read the introduction and work through some of the
tutorials before trying to tackle a full PyOgre project.

[Last Notes]
There is a list of outstanding bugs for pyogre here:
http://developer.berlios.de/bugs/?group_id=3464

Feel free to add to it if you find problems.  If possible please include a
short code snippet which reproduces the problem.  You may also post problems
to the PyOgre forums, but it's vital that you open up a bug so that your
problem does not get overlooked.

Team PyOgre
