#ifndef _IndexBufferProxy_h_
#define _IndexBufferProxy_h_

#include <OgreHardwareIndexBuffer.h>

class IndexBufferProxy
{
public:
   IndexBufferProxy(Ogre::HardwareIndexBuffer *buffer,
                    void *data,
                    Ogre::uint32 length);
   Ogre::uint32 __len__();
   Ogre::uint32 __getitem__(Ogre::uint32 index);
   void __setitem__(Ogre::uint32 index, Ogre::uint32 value);
private:
   Ogre::HardwareIndexBuffer *mBuffer;
   void *mData;
   Ogre::uint32 mLength;
   bool mUseShortIndex;
};

#endif
