#include "VertexBufferProxy.h"

VertexBufferProxy::VertexBufferProxy(Ogre::HardwareVertexBuffer *buffer,
                        const Ogre::VertexDeclaration &declaration, void *data)
: mData(static_cast<Ogre::uint8*>(data)),
  mVertexSize((Ogre::uint32)buffer->getVertexSize())
{
    Ogre::VertexDeclaration::VertexElementList::const_iterator itr;
    
    for (itr = declaration.getElements().begin(); itr != declaration.getElements().end(); ++itr )
        mElementOffsets.push_back((const Ogre::uint32)itr->getOffset());
}


VertexBufferProxy::~VertexBufferProxy()
{
}


PyObject *VertexBufferProxy::getFloat(Ogre::uint32 index, Ogre::uint32 element,
                                      Ogre::uint32 length)
{
    float *data = getVertexElementLocation<float>(index, element);
    
    Ogre::uint32 i;
    PyObject *toReturn = PyTuple_New(length);

    if (toReturn)
        for (i = 0; i < length; ++i)
            PyTuple_SET_ITEM(toReturn, i, PyFloat_FromDouble(data[i]));

    return toReturn;
}


void VertexBufferProxy::setFloat(Ogre::uint32 index, Ogre::uint32 element,
                                 float x)
{
    float *data = getVertexElementLocation<float>(index, element);
    data[0] = x;
}


void VertexBufferProxy::setFloat(Ogre::uint32 index, Ogre::uint32 element,
                                 float x, float y)
{
    float *data = getVertexElementLocation<float>(index, element);
    data[0] = x;
    data[1] = y;
}


void VertexBufferProxy::setFloat(Ogre::uint32 index, Ogre::uint32 element,
                                 const Ogre::Vector2 &v)
{
    float *data = getVertexElementLocation<float>(index, element);
    data[0] = v.x;
    data[1] = v.y;
}


void VertexBufferProxy::setFloat(Ogre::uint32 index, Ogre::uint32 element,
                                 float x, float y, float z)
{
    float *data = getVertexElementLocation<float>(index, element);
    data[0] = x;
    data[1] = y;
    data[2] = z;
} // setFloat3


void VertexBufferProxy::setFloat(Ogre::uint32 index, Ogre::uint32 element,
                                 const Ogre::Vector3 &v)
{
    float *data = getVertexElementLocation<float>(index, element);
    data[0] = v.x;
    data[1] = v.y;
    data[2] = v.z;
} // setFloat3


void VertexBufferProxy::setShort(Ogre::uint32 index, Ogre::uint32 element,
                                 Ogre::uint16 x)
{
    Ogre::uint16 *data = getVertexElementLocation<Ogre::uint16>(index, element);
    data[0] = x;
}


void VertexBufferProxy::setShort(Ogre::uint32 index, Ogre::uint32 element,
                                 Ogre::uint16 x, Ogre::uint16 y)
{
    Ogre::uint16 *data = getVertexElementLocation<Ogre::uint16>(index, element);
    data[0] = x;
    data[1] = y;
}


PyObject *VertexBufferProxy::getShort(Ogre::uint32 index, Ogre::uint32 element,
                                      Ogre::uint32 length)
{
    Ogre::uint16 *data = getVertexElementLocation<Ogre::uint16>(index, element);
    
    PyObject *toReturn = PyTuple_New(length);

    if (toReturn)
        for (unsigned int i = 0; i < length; ++i)
            PyTuple_SET_ITEM(toReturn, i, PyInt_FromLong((long)data[i]));

    return toReturn;
}


void VertexBufferProxy::setShort(Ogre::uint32 index, Ogre::uint32 element,
                                 Ogre::uint16 x, Ogre::uint16 y,
                                 Ogre::uint16 z)
{
    Ogre::uint16 *data = getVertexElementLocation<Ogre::uint16>(index, element);
    data[0] = x;
    data[1] = y;
    data[2] = z;
}


void VertexBufferProxy::setShort(Ogre::uint32 index, Ogre::uint32 element,
                                 Ogre::uint16 x, Ogre::uint16 y,
                                 Ogre::uint16 z, Ogre::uint16 w)
{
    Ogre::uint16 *data = getVertexElementLocation<Ogre::uint16>(index, element);
    data[0] = x;
    data[1] = y;
    data[2] = z;
    data[3] = w;
}


void VertexBufferProxy::setByte(Ogre::uint32 index, Ogre::uint32 element,
                                Ogre::uint8 x, Ogre::uint8 y, Ogre::uint8 z,
                                Ogre::uint8 w)
{
    Ogre::uint8 *data = getVertexElementLocation<Ogre::uint8>(index, element);
    data[0] = x;
    data[1] = y;
    data[2] = z;
    data[3] = w;
}


void VertexBufferProxy::setByte(Ogre::uint32 index, Ogre::uint32 element,
                                const Ogre::Vector4 &v)
{
    Ogre::uint8 *data = getVertexElementLocation<Ogre::uint8>(index, element);
    data[0] = v.x;
    data[1] = v.y;
    data[2] = v.z;
    data[3] = v.w;
}


PyObject *VertexBufferProxy::getByte(Ogre::uint32 index, Ogre::uint32 element,
                                     Ogre::uint32 length)
{
    Ogre::uint8 *data = getVertexElementLocation<Ogre::uint8>(index, element);
    
    PyObject *toReturn = PyTuple_New(length);

    if (toReturn)
        for (unsigned int i = 0; i < length; ++i)
            PyTuple_SET_ITEM(toReturn, i, PyInt_FromLong((long)data[i]));

    return toReturn;
}


void VertexBufferProxy::setColour(Ogre::uint32 index, Ogre::uint32 element,
                                  Ogre::uint32 x)
{
   Ogre::uint32 *data = getVertexElementLocation<Ogre::uint32>(index, element);
   data[0] = x;
}


void VertexBufferProxy::setColour(Ogre::uint32 index, Ogre::uint32 element,
                                  const Ogre::ColourValue &colour)
{
   Ogre::uint32 packedColour;
   Ogre::Root::getSingleton().convertColourValue(colour, &packedColour);
   setColour(index, element, packedColour);
}


Ogre::uint32 VertexBufferProxy::getColour(Ogre::uint32 index, Ogre::uint32 element)
{
   Ogre::uint32 *data = getVertexElementLocation<Ogre::uint32>(index, element);
   return data[0];
}
