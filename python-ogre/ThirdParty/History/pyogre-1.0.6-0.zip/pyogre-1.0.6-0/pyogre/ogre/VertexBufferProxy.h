#ifndef _VertexBufferProxy_h_
#define _VertexBufferProxy_h_

#include <vector>
#include <Ogre.h>
#include <OgreColourValue.h>
#include <OgreHardwareVertexBuffer.h>
#include <Python.h>

class VertexBufferProxy
{
public:
    VertexBufferProxy(Ogre::HardwareVertexBuffer *buffer,
                      const Ogre::VertexDeclaration &declaration,
                      void *data);
    ~VertexBufferProxy();

    void setFloat(Ogre::uint32 index, Ogre::uint32 element, float x);

    void setFloat(Ogre::uint32 index, Ogre::uint32 element, float x,
                  float y);
    void setFloat(Ogre::uint32 index, Ogre::uint32 element,
                  const Ogre::Vector2 &v);

    void setFloat(Ogre::uint32 index, Ogre::uint32 element, float x, float y,
                  float z);
    void setFloat(Ogre::uint32 index, Ogre::uint32 element,
                  const Ogre::Vector3 &v);

    PyObject* getFloat(Ogre::uint32 index, Ogre::uint32 element,
                       Ogre::uint32 length);

    void setShort(Ogre::uint32 index, Ogre::uint32 element, Ogre::uint16 x);
    void setShort(Ogre::uint32 index, Ogre::uint32 element, Ogre::uint16 x,
                  Ogre::uint16 y);
    void setShort(Ogre::uint32 index, Ogre::uint32 element, Ogre::uint16 x,
                  Ogre::uint16 y, Ogre::uint16 z);

    void setShort(Ogre::uint32 index, Ogre::uint32 element, Ogre::uint16 x,
                  Ogre::uint16 y, Ogre::uint16 z, Ogre::uint16 w);
    
    PyObject *getShort(Ogre::uint32 index, Ogre::uint32 element, Ogre::uint32 length);

    void setByte(Ogre::uint32 index, Ogre::uint32 element, Ogre::uint8 x,
                 Ogre::uint8 y, Ogre::uint8 z, Ogre::uint8 w);
    void setByte(Ogre::uint32 index, Ogre::uint32 element, const Ogre::Vector4 &v);
    PyObject *getByte(Ogre::uint32 index, Ogre::uint32 element, Ogre::uint32 length);

    void setColour(Ogre::uint32 index, Ogre::uint32 element, Ogre::uint32 x);
    void setColour(Ogre::uint32 index, Ogre::uint32 element,
                   const Ogre::ColourValue &colour);
    Ogre::uint32 getColour(Ogre::uint32 index, Ogre::uint32 element);

protected:
    template<typename DataType>
    inline DataType *getVertexElementLocation(Ogre::uint32 index, Ogre::uint32 element)
    {
        Ogre::uint8 *data = &mData[mVertexSize * index + mElementOffsets[element]];
        return reinterpret_cast<DataType *>(data);
    }

private:
    std::vector<Ogre::uint32> mElementOffsets;
    Ogre::uint32 mVertexSize;
    Ogre::uint8 *mData;
};

#endif
