#include "IndexBufferProxy.h"

IndexBufferProxy::IndexBufferProxy(Ogre::HardwareIndexBuffer *buffer,
                                   void *data,
                                   Ogre::uint32 length)
: mBuffer(buffer), mData(data), mLength(length),
  mUseShortIndex(buffer->getType() == Ogre::HardwareIndexBuffer::IT_16BIT)
{
}

Ogre::uint32 IndexBufferProxy::__len__()
{
    return mLength;
}


Ogre::uint32 IndexBufferProxy::__getitem__(Ogre::uint32 index)
{
   if (mUseShortIndex)
      return static_cast<Ogre::uint16 *>(mData)[index];

   return static_cast<Ogre::uint32 *>(mData)[index];
}


void IndexBufferProxy::__setitem__(Ogre::uint32 index, Ogre::uint32 value)
{
    if (mUseShortIndex)
        static_cast<Ogre::uint16 *>(mData)[index] = value;
    else
        static_cast<Ogre::uint32 *>(mData)[index] = value;
}
