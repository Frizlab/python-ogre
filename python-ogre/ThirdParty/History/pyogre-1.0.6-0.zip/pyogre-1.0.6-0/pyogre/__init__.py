# pyogre/__init__.py - top-level pyogre module
#
# Copyright (C) 2004 PyOgre Core Team
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 2, or (at your option) any later
# version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTIBILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.

__all__ = ['ogre', 'cegui']

import sys, os

if sys.platform == 'win32':
    os.environ['PATH'] += ';' + __path__[0]

del sys, os
