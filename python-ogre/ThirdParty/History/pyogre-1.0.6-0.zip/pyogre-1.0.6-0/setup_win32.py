# setup.py - distutils packaging
#
# Copyright (C) 2005 PyOgre Core Team
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 2, or (at your option) any later
# version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTIBILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.

"""Ogre 3D Engine for Python

The PyOgre module provides Python bindings for the Ogre 3D
rendering engine.
"""

classifiers = """\
Development Status :: 4 - Beta
Intended Audience :: Developers
License :: OSI Approved :: GNU Lesser General Public License (LGPL)
Programming Language :: Python
Programming Language :: C++
Topic :: Software Development
Topic :: Software Development :: Libraries :: Python Modules
Operating System :: Microsoft :: Windows
Operating System :: Unix
"""

PYOGRE_VERSION = '1.0.6.0'

import os
from distutils.core import setup

def demosFilter(x):
    return (not x.endswith("ogre.cfg")) and (x.endswith(".py") or x.endswith(".cfg"))


def buildFileList(localDir, installDir, filterFunction = None):
    toReturn = []
    
    if installDir is None:
        installDir = localDir

    if localDir[-1:] != "/" or localDir[-1:] != "\\":
        localDir += '/'

    if installDir[-1:] != "/" or installDir[-1:] != "\\":
        installDir += '/'

    files = [localDir + x for x in os.listdir(localDir) if os.path.isfile(localDir + x)]
    if filterFunction is not None:
        files = [x for x in files if filterFunction(x)]

    return [(installDir[:-1], files)]



df  = buildFileList('demos/ogre', 'pyogre/ogre_demos', demosFilter)

tutorials = buildFileList('demos/tutorials', 'pyogre/tutorials', demosFilter)
tutorials[0][1].append('demos/ogre/SampleFramework.py')
df += tutorials

cegui_demos  = buildFileList('demos/cegui', 'pyogre/cegui_demos', demosFilter)
cegui_demos += buildFileList('demos/cegui/layouts', 'pyogre/cegui_demos/layouts')
cegui_demos[0][1].append('demos/ogre/SampleFramework.py')
df += cegui_demos

ogre_tools = buildFileList('demos/tools', 'pyogre/tools', demosFilter)
ogre_tools += buildFileList('demos/tools/resources', 'pyogre/tools/resources')
ogre_tools += buildFileList('demos/tools/licenses', 'pyogre/tools/licenses')
ogre_tools[0][1].append('demos/ogre/SampleFramework.py')
df += ogre_tools

df += buildFileList('pyogre/dlls/ogre/release/', 'Lib/site-packages/pyogre')
df += buildFileList('pyogre/dlls/cegui/release/', 'Lib/site-packages/pyogre')

df += [('pyogre', ['docs/readme_win32.txt', 'AUTHORS', 'ChangeLog', 'COPYING'])]
df += [('Lib/site-packages/pyogre', ['pyogre/_ogre.pyd', 'pyogre/_cegui.pyd', 'pyogre/plugins.cfg'])]

setup(name="pyogre",
      version=PYOGRE_VERSION,
      data_files=df,
      maintainer="PyOgre Core Team",
      maintainer_email="clay@idleengineer.net",
      author="PyOgre Core Team",
      author_email="clay@idleengineer.net",
      url="http://www.ogre3d.org/wiki/index.php/PyOgre",
      download_url = "http://developer.berlios.de/project/showfiles.php?group_id=3464",
      license="LGPL",
      platforms = ["any"],
      description=__doc__.split("\n")[0],
      long_description="\n".join(__doc__.split("\n")[2:]),
      classifiers=[x for x in classifiers.split("\n") if x != ''],
      packages=['pyogre']
      )

