# Unit tests for Ray
# 
# Copyright (C) 2005 PyOgre Core Team
# 
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
# 
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
# 
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
from helpers import *
import BaseTestPlane

class PlaneTests(BaseTestPlane.PlaneTests, TestCase):
    """Test cases for ogre.Plane."""

    def test___eq__(self):
        """Unit test for ogre.Plane.__eq__()"""
        p1 = ogre.Plane(ogre.Vector3(1, 2, 3), 32)
        p2 = ogre.Plane(ogre.Vector3(1, 2, 3), ogre.Vector3(4, 5, 6))
        self.failUnless(p1 == p2)
        
        p1.d = 7
        self.failIf(p1 == p2)

        p1 = ogre.Plane(ogre.Vector3(-1, 0, 1), 3)
        p2 = ogre.Plane()
        p2.normal = ogre.Vector3(-1, 0, 1)
        p2.d = -3
        self.failUnless(p1 == p2)

    def test___init__(self):
        """Unit test for ogre.Plane.__init__()"""
        p1 = ogre.Plane()
        self.failUnless(p1.d == 0)
        self.failUnless(p1.normal == ogre.Vector3(0, 0, 0))

        p1 = ogre.Plane((-1, 0, 1), 3)
        p2 = ogre.Plane(p1)
        self.failUnless(p1 == p2)
        self.failIf(issame(p1, p2))

        p1 = ogre.Plane((1, 2, 3), (-4, -5, 7))
        self.failUnless(p1.normal == ogre.Vector3(1, 2, 3))
        self.failUnless(p1.d == -7)

        p1 = ogre.Plane((1, 1, 0), (0, 1, 1), (1, 1, 1))
        self.failUnless(p1.d == -1.0)
        self.failUnless(p1.normal == ogre.Vector3(0, 1, 0))

    def test_getSide(self):
        """Unit test for ogre.Plane.getSide()"""
        p1 = ogre.Plane((1, 1, 0), (0, 1, 1), (1, 1, 1))
        self.failUnless(p1.getSide((2, 3, 4)) ==  ogre.Plane.POSITIVE_SIDE)
        self.failUnless(p1.getSide((-2, -3, -4)) == ogre.Plane.NEGATIVE_SIDE)
        self.failUnless(p1.getSide((1, 1, 1)) == ogre.Plane.NO_SIDE)

    def test_getDistance(self):
        """Unit test for ogre.Plane.getDistance()"""
        p1 = ogre.Plane((0, 0, 1), 3)
        self.failUnless(p1.getDistance((0,0,0)) == -3)
        
    def test_redefine(self):
        """Unit test for ogre.Plane.redefine()"""
        p1 = ogre.Plane((-1, 0, 1), 3)
        p1.redefine((1, 1, 0), (0, 1, 1), (1, 1, 1))
        self.failUnless(p1.d == -1.0)
        self.failUnless(p1.normal == (0, 1, 0))

    def test_d(self):
        """Unit test for ogre.Plane.d"""
        p1 = ogre.Plane((-1, 0, 1), 3)
        self.failUnless(p1.d == -3)

        p1.d = 4
        self.failUnless(p1.d == 4)

    def test_normal(self):
        """Unit test for ogre.Plane.normal"""
        p1 = ogre.Plane((-1, 0, 1), 3)
        self.failUnless(p1.normal == ogre.Vector3(-1, 0, 1))
        self.failUnless(p1.normal == (-1, 0, 1))
        
        p1.normal = -2, 2, 2
        self.failUnless(p1.normal == ogre.Vector3(-2, 2, 2))
        self.failUnless(p1.normal == (-2, 2, 2))

        p1.normal = ogre.Vector3(-2, 2, 2)
        self.failUnless(p1.normal == ogre.Vector3(-2, 2, 2))
        self.failUnless(p1.normal == (-2, 2, 2))

        
