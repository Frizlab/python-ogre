# Unit tests for Ray
# 
# Copyright (C) 2005 PyOgre Core Team
# 
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
# 
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
# 
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
from helpers import *
import BaseTestRay

class RayTests(TestCase, BaseTestRay.RayTests):
    """Test cases for Ray."""

    def test___init__(self):
        """Unit test for Ray.__init__()"""
        r1 = ogre.Ray( )
        self.failUnlessOwned(r1)

        r2 = ogre.Ray(ogre.Vector3(1, 2, 3), ogre.Vector3(4, 5, 6))
        self.failUnless(r2.origin == ogre.Vector3(1, 2, 3))
        self.failUnless(r2.direction == ogre.Vector3(4, 5, 6))
        self.failUnlessOwned(r2)

        # test overloaded Vector3/3-tuples
        r2 = ogre.Ray((1, 2, 3), (4, 5, 6))
        self.failUnless(r2.origin == (1, 2, 3))
        self.failUnless(r2.direction == (4, 5, 6))
        self.failUnlessOwned(r2)        

        r1 = ogre.Ray(r2)
        self.failIf(issame(r1, r2))
        self.failUnless(r2.direction == r1.direction)
        self.failUnless(r2.origin == r1.origin)
        self.failUnlessOwned(r2)

    def test___mul__(self):
        """Unit test for Ray.__mul__()"""
        r = ogre.Ray((1, 2, 3), (7, 4, 2))
        v = r * 3
        self.failUnless(v == (22, 14, 9))

    def test_getPoint(self):
        """Unit test for Ray.getPoint()"""
        r = ogre.Ray((1, 2, 3), (7, 4, 2))
        v = r.getPoint(2)
        self.failUnless(v == (15, 10, 7))

    def test_intersects(self):
        """Unit test for Ray.intersects()"""
        self.fail('test case not implemented')

    def test_direction(self):
        """Unit test for Ray.direction"""
        r = ogre.Ray((1, 2, 3), (4, 5, 6))
        self.failUnless(r.direction == (4, 5, 6))
        self.failIfOwned(r.direction)

        r.direction = ogre.Vector3(-1, -2, -3)
        self.failUnless(r.direction == (-1, -2, -3))
        self.failIfOwned(r.direction)

        r.direction = (7, 8, 9)
        self.failUnless(r.direction == (7, 8, 9))
        self.failIfOwned(r.direction)

        v = r.direction
        v.x = 0
        v.y = 1
        v.z = 2

        self.failIfOwned(v)
        self.failUnless(v == (0, 1, 2))
        self.failUnless(r.direction == (0, 1, 2))

        r.direction.x += 2
        r.direction.y = 3
        v.z = 4
        
        self.failUnless(v == (2, 3, 4))
        self.failUnless(r.direction == (2, 3, 4))

    def test_origin(self):
        """Unit test for Ray.origin"""
        r = ogre.Ray((1, 2, 3), (4, 5, 6))
        self.failUnless(r.origin == ( 1, 2, 3 ))
        self.failIfOwned(r.origin)

        r.origin = ogre.Vector3(-1, -2, -3)
        self.failUnless(r.origin == (-1, -2, -3))
        self.failIfOwned(r.origin)

        r.origin = (7, 8, 9)
        self.failUnless(r.origin == (7, 8, 9))
        self.failIfOwned(r.origin)

        v = r.origin
        v.x = 0
        v.y = 1
        v.z = 2

        self.failIfOwned(v)
        self.failUnless(v == (0, 1, 2))
        self.failUnless(r.origin == (0, 1, 2))

        r.origin.x += 2
        r.origin.y = 3
        v.z = 4
        
        self.failUnless(v == (2, 3, 4))
        self.failUnless(r.origin == (2, 3, 4))
