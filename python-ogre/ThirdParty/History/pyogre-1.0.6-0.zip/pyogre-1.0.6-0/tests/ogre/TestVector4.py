# Unit tests for Vector3
#
# Copyright (C) 2005 PyOgre Core Team
# 
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
# 
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
# 
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
from helpers import *
import BaseTestVector4

class Vector4Tests(TestCase, BaseTestVector4.Vector4Tests):
    # constructor tests

    def test___init__(self):
        """Unit test for Vector4.__init__()"""
        v = ogre.Vector4()
        self.failUnless(v.thisown == 1)

        v = ogre.Vector4(0, 1, -1, 0)
        self.failUnless(v.thisown == 1)
        self.failUnless(cp4(v, 0.0, 1.0, -1.0, 0.0))

        v = ogre.Vector4(0.0, 1.0, -1.0, 2.0)
        self.failUnless(v.thisown == 1)
        self.failUnless(cp4(v, 0.0, 1.0, -1.0, 2.0))

        v = ogre.Vector4(1, 2, 3, 4)
        r = ogre.Vector4(v)
        self.failUnless(r.thisown == 1)
        self.failUnless(cp4(r, 1.0, 2.0, 3.0, 4.0))
        self.failIf( issame(v, r) )

        # test tuple expansion
        v = ogre.Vector4(1, 2, 3, 4)
        self.failUnless( v == (1, 2, 3, 4) )
        self.failUnless( v == ogre.Vector4( 1, 2, 3, 4 ) )

    def test___getitem__(self):
        """Unit test for Vector4.__getitem__()"""
        v = ogre.Vector4(1, 2, 3, 4)
        self.failUnless(v[0] == 1.0 and v[1] == 2.0 and v[2] == 3.0 and v[3] == 4.0)

    def test___eq__(self):
        """Unit test for Vector4.__eq__()"""
        v1 = ogre.Vector4(1, 2, 3, 4)

        v2 = ogre.Vector4(1, 2, 3, 4)
        self.failUnless(v1 == v2)

    def test___ne__(self):
        """Unit test for Vector4.__ne__()"""
        v1 = ogre.Vector4(1, 2, 3, 4)
        v2 = ogre.Vector4(3, 4, 5, 6)
        self.failUnless(v1 != v2)
        
    def test___add__(self):
        """Unit test for Vector4.__add__()"""
        v1 = ogre.Vector4(1, 2, 3, 4)
        v2 = ogre.Vector4(3, 4, 5, 6)
        
        r = v1 + v2
        self.failUnless(r.thisown == 1)
        self.failUnless(cp4(r, 4.0, 6.0, 8.0, 10.0))

    def test___neg__(self):
        """Unit test for Vector4.__neg__()"""
        v1 = ogre.Vector4(1, 2, 3, 4)
        v2 = ogre.Vector4(3, 4, 5, 6)

        self.failUnless( -v1 == (-1, -2, -3, -4) )
        self.failUnless( (-3, -4, -5, -6) == -v2 )
        
        
    def test___iadd__(self):
        """Unit test for Vector4.__iadd__()"""
        v1 = ogre.Vector4(1, 2, 3, 4)
        v2 = ogre.Vector4(3, 4, 5, 6)
        
        v1 += v2
        self.failUnless(v1.thisown == 1)
        self.failUnless(cp4(v1, 4.0, 6.0, 8.0, 10.0))

    def test___sub__(self):
        """Unit test for Vector4.__sub__()"""        
        v1 = ogre.Vector4(1, 2, 3, 4)
        v2 = ogre.Vector4(3, 4, 5, 6)
        
        r = v1 - v2
        self.failUnless(r.thisown == 1)
        self.failUnless(cp4(r, -2.0, -2.0, -2.0, -2.0))

    def test___isub__(self):
        """Unit test for Vector4.__isub__()"""
        v1 = ogre.Vector4(1, 2, 3, 4)
        v2 = ogre.Vector4(3, 4, 5, 6)
        
        v1 -= v2
        self.failUnless(v1.thisown == 1)
        self.failUnless(cp4(v1, -2.0, -2.0, -2.0, -2.0))

    def test___mul__(self):
        """Unit test for Vector4.__mul__()"""
        v1 = ogre.Vector4(1, 2, 3, 4)
        v2 = ogre.Vector4(3, 4, 5, 6)
        
        r = v1 * 2 # note that '2' is a scalar here
        self.failUnless(r.thisown == 1)
        self.failUnless(cp4(r, 2.0, 4.0, 6.0, 8.0))

        r = v1 * v2 # note that 'v2' is a vector here
        self.failUnless(r.thisown == 1)
        self.failUnless(cp4(r, 3.0, 8.0, 15.0, 24.0))

    def test___imul__(self):
        """Unit test for Vector4.__imul__()"""
        v1 = ogre.Vector4(1, 2, 3, 4)
        v2 = ogre.Vector4(3, 4, 5, 6)
        
        v1 *= 2 # note that '2' is a scalar here
        self.failUnless(v1.thisown == 1)
        self.failUnless(cp4(v1, 2.0, 4.0, 6.0, 8.0))

        v1 = ogre.Vector4(1, 2, 3, 4)
        v1 *= v2 # note that 'v2' is a vector here
        self.failUnless(v1.thisown == 1)
        self.failUnless(cp4(v1, 3.0, 8.0, 15.0, 24.0))

    def test___div__(self):
        """Unit test for Vector4.__div__()"""
        v1 = ogre.Vector4(1, 2, 3, 4)
        v2 = ogre.Vector4(3, 4, 5, 6)

        r = v1 / 2 # note that '2' is a scalar here
        self.failUnless(r.thisown == 1)
        self.failUnless(cp4(r, 0.5, 1.0, 1.5, 2.0))

    def test___idiv__(self):
        """Unit test for Vector4.__idiv__()"""
        v1 = ogre.Vector4(1, 2, 3, 4)
        v2 = ogre.Vector4(3, 4, 5, 6)

        v1 /= 2 # note that '2' is a scalar here
        self.failUnless(v1.thisown == 1)
        self.failUnless(cp4(v1, 0.5, 1.0, 1.5, 2.0))
        

    def test_w(self):
        """Unit test for Vector4.w"""
        v1 = ogre.Vector4(1, 2, 3, 4)
        v2 = ogre.Vector4(5, 6, 7, 8)

        self.failUnless(v1.w == 4)
        self.failUnless(v2.w == 8)
        

    def test_x(self):
        """Unit test for Vector4.x"""
        v1 = ogre.Vector4(1, 2, 3, 4)
        v2 = ogre.Vector4(5, 6, 7, 8)

        self.failUnless(v1.x == 1)
        self.failUnless(v2.x == 5)

    def test_y(self):
        """Unit test for Vector4.y"""
        v1 = ogre.Vector4(1, 2, 3, 4)
        v2 = ogre.Vector4(5, 6, 7, 8)

        self.failUnless(v1.y == 2)
        self.failUnless(v2.y == 6)

    def test_z(self):
        """Unit test for Vector4.z"""
        v1 = ogre.Vector4(1, 2, 3, 4)
        v2 = ogre.Vector4(5, 6, 7, 8)

        self.failUnless(v1.z == 3)
        self.failUnless(v2.z == 7)

    def test_dotProduct(self):
        """Unit test for Vector4.dotProduct()"""
        v1 = ogre.Vector4(1, 2, 3, 4)
        v2 = ogre.Vector4(5, 6, 7, 8)

        self.failUnless(v1.dotProduct(v2) == 70)

    def test___nonzero__(self):
        """Unit test for Vector4.__nonzero__()"""
        # these are false
        f1 = ogre.Vector4(0, 0, 0, 0)
        f2 = ogre.Vector4(0.0, 0.0, 0.0, 0.0)

        # these are true
        t1 = ogre.Vector4(1, 2, 3, 4)
        t2 = ogre.Vector4(1, 0, 0, 0)
        t3 = ogre.Vector4(0, 0, 0, 1)

        # Note this tests the boundary condition. The method of testing should
        # be at most this accurate, and evaluate this to true:
        t4 = ogre.Vector4(0.00001, 0, 0, 0)

        self.failIf(f1)
        self.failIf(f2)

        self.failUnless(t1)
        self.failUnless(t2)
        self.failUnless(t3)
        self.failUnless(t4)

    def test_inplaceCrash(self):
	"""Test for segfaults in inplace operators."""
	x = ogre.Vector4(0, 0, 0, 0)
	v = ogre.Vector4(1, 1, 0, 0)
	w = v
	v += x
	w += x
	del v
	del w


if __name__ == '__main__':
    unittest.main()
