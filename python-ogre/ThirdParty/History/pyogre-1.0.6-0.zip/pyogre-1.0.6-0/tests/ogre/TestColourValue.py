# TestColourValue.py - unit tests for the ColourValue class
#
# Copyright (C) 2005 PyOgre Core Team
# 
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
# 
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
# 
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

from helpers import *
import BaseTestColourValue

class ColourValueTests(TestCase, BaseTestColourValue.ColourValueTests):

    def test___init__(self):
        """Unit test for ColourValue.__init__()"""
        c1 = ogre.ColourValue(1, 1, 1, 1)
        self.failUnlessOwned(c1)

    def test_typemap(self):
        """Unit test for the ColourValue typemap"""
        c1 = ogre.ColourValue(1, 1, 1, 1)
        self.failUnless( c1 == (1, 1, 1, 1) )
        
    def test___add__(self):
        """Unit test for ColourValue.__add__()"""
        # ugh! Ogre does not clip colour components
        c1 = ogre.ColourValue(0, 0.5, 1, .3)
        c2 = ogre.ColourValue(1, 0.5, 1, .3)
        self.failUnless(c1 + c2 == (1, 1, 2, .6))

    def test___div__(self):
        """Unit test for ColourValue.__div__()"""
        c1 = ogre.ColourValue(0, 0.5, 1, 1)
        c2 = ogre.ColourValue(2, 2, 1, .5)
        self.failUnless(c1/c2 == (0, .25, 1, 2))
        self.failUnless(c1/2 == (0, .25, .5, .5))

    def test___eq__(self):
        """Unit test for ColourValue.__eq__()"""
        c1 = ogre.ColourValue(1, 0.5, 1, .3)
        c2 = ogre.ColourValue(1, 0.5, 1, .3)
        c3 = ogre.ColourValue(1, 1, 1, .6)
        self.failUnless(c1 == c2)
        self.failIf(c1 == c3)
        
    def test___iadd__(self):
        """Unit test for ColourValue.__iadd__()"""
        c1 = ogre.ColourValue(0, 0.5, 1, .3)
        c2 = ogre.ColourValue(1, 0.5, 1, .3)
        c3 = ogre.ColourValue(1, 1, 2, .6)
        cx = c1 ; c1 += c2
        self.failUnless(issame(c1, cx))
        self.failUnless(cx == c3)
        self.failUnless(c1 == c3)

    def test___idiv__(self):
        """Unit test for ColourValue.__idiv__()"""
        c1 = ogre.ColourValue(0, 0.5, 1, 1)
        c2 = ogre.ColourValue(0, .25, .5, .5)
        cx = c1
        c1 /= 2
        self.failUnless(issame(c1, cx))
        self.failUnless(c1 == cx)
        self.failUnless(c1 == c2)

    def test___imul__(self):
        """Unit test for ColourValue.__imul__()"""
        c1 = ogre.ColourValue(0, 0.5, 1, -2)
        c2 = ogre.ColourValue(0, 1, 2, -4)
        cx = c1
        c1 *= 2
        self.failUnless(issame(c1, cx))
        self.failUnless(c1 == cx)
        self.failUnless(c1 == c2)

    def test___isub__(self):
        """Unit test for ColourValue.__isub__()"""
        c1 = ogre.ColourValue(0, 0.5, 1, .3)
        c2 = ogre.ColourValue(1, 0.5, 1, -.3)
        c3 = ogre.ColourValue(-1, 0, 0, .6)
        cx = c1 ; c1 -= c2
        self.failUnless(issame(c1, cx))
        self.failUnless(cx == c3)
        self.failUnless(c1 == c3)

    def test___mul__(self):
        """Unit test for ColourValue.__mul__()"""
        c1 = ogre.ColourValue(0, 0.5, 1, .5)
        c2 = ogre.ColourValue(2, 2, 1, .5)
        c3 = ogre.ColourValue(0, 1, 1, .25)
        c4 = ogre.ColourValue(0, 1, 2, 1)
        self.failUnless(c1*c2 == c3)
        self.failUnless(c1*2 == c4)

    def test___ne__(self):
        """Unit test for ColourValue.__ne__()"""
        c1 = ogre.ColourValue(1, 0.5, 1, .3)
        c2 = ogre.ColourValue(1, 0.5, 1, .3)
        c3 = ogre.ColourValue(1, 1, 1, .6)
        self.failIf(c1 != c2)
        self.failUnless(c1 != c3)

    def test___sub__(self):
        """Unit test for ColourValue.__sub__()"""
        c1 = ogre.ColourValue(0, 0.5, 1, .3)
        c2 = ogre.ColourValue(1, 0.5, 1, -.3)
        c3 = ogre.ColourValue(-1, 0, 0, .6)
        self.failUnless(c1 - c2 == c3)

    def test_a(self):
        """Unit test for ColourValue.a"""
        c1 = ogre.ColourValue(1, 0.5, 1, .25)
        self.failUnless(c1.a == .25)

    def test_abgr(self):
        """Unit test for ColourValue.abgr"""
        c1 = ogre.ColourValue(1, 0.5, 1, .4)
        self.failUnless(c1.abgr == 1728020479)

    def test_argb(self):
        """Unit test for ColourValue.argb"""
        c1 = ogre.ColourValue(1, 0.5, 1, .4)
        self.failUnless(c1.argb == 1728020479)

    def test_b(self):
        """Unit test for ColourValue.b"""
        c1 = ogre.ColourValue(1, 0.5, 1, .3)
        self.failUnless(c1.b == 1)

    def test_g(self):
        """Unit test for ColourValue.g"""
        c1 = ogre.ColourValue(1, 0.5, 1, .3)
        self.failUnless(c1.g == 0.5)

    def test_r(self):
        """Unit test for ColourValue.r"""
        c1 = ogre.ColourValue(1, 0.5, 1, .3)
        self.failUnless(c1.r == 1)

    def test_rgba(self):
        """Unit test for ColourValue.rgba"""
        c1 = ogre.ColourValue(1, 0.5, 1, .4)
        # with a 32 bit number starting with 0xff we need a large int here
        self.failUnless(c1.rgba == 4286578534L)

    def test_Red(self):
        """Unit test for ColourValue.Red"""
        self.failUnless(ogre.ColourValue(1, 0, 0, 1) == ogre.ColourValue.Red)
        
        cv = ogre.ColourValue.Red
        self.failUnless(cv == (1, 0, 0, 1) )
        cv.r = 0  # this will cause an error in the next test if we change Red

        cv = ogre.ColourValue( ogre.ColourValue.Red )
        self.failUnless(cv == (1, 0, 0, 1) )
        
    def test_Green(self):
        """Unit test for ColourValue.Green"""
        self.failUnless(ogre.ColourValue(0, 1, 0, 1) == ogre.ColourValue.Green)
        
        cv = ogre.ColourValue.Green
        self.failUnless(cv == (0, 1, 0, 1) )
        cv.g = 0  # this will cause an error in the next test if we change Green

        cv = ogre.ColourValue( ogre.ColourValue.Green )
        self.failUnless(cv == (0, 1, 0, 1) )

    def test_Blue(self):
        """Unit test for ColourValue.Blue"""
        self.failUnless(ogre.ColourValue(0, 0, 1, 1) == ogre.ColourValue.Blue)
        
        cv = ogre.ColourValue.Blue
        self.failUnless(cv == (0, 0, 1, 1) )
        cv.b = 0  # this will cause an error in the next test if we change Blue

        cv = ogre.ColourValue( ogre.ColourValue.Blue )
        self.failUnless(cv == (0, 0, 1, 1) )

    def test_White(self):
        """Unit test for ColourValue.White"""
        self.failUnless(ogre.ColourValue(1, 1, 1, 1) == ogre.ColourValue.White)
        
        cv = ogre.ColourValue.White
        self.failUnless(cv == (1, 1, 1, 1) )
        cv.b = 0  # this will cause an error in the next test if we change White

        cv = ogre.ColourValue( ogre.ColourValue.White )
        self.failUnless(cv == (1, 1, 1, 1) )
        
    def test_Black(self):
        """Unit test for ColourValue.Black"""
        self.failUnless(ogre.ColourValue(0, 0, 0, 1) == ogre.ColourValue.Black)
        
        cv = ogre.ColourValue.Black
        self.failUnless(cv == (0, 0, 0, 1) )
        cv.b = 1  # this will cause an error in the next test if we change Black

        cv = ogre.ColourValue( ogre.ColourValue.Black )
        self.failUnless(cv == (0, 0, 0, 0) )
        
