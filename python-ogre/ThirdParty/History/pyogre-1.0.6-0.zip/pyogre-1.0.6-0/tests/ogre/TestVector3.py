# Unit tests for Vector3
# 
# Copyright (C) 2005 PyOgre Core Team
# 
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
# 
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
# 
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import unittest

from helpers import *
import BaseTestVector3

class Vector3Tests(TestCase, BaseTestVector3.Vector3Tests):
    """Test cases for Vector3."""
    
    def test___add__(self):
        """Unit test for Vector3.__add__()"""
        v1 = ogre.Vector3( 1, 2, 3)
        v2 = ogre.Vector3(-1,-2,-3)
        self.failUnless(v1 + v2 == (0, 0, 0))

    def test___div__(self):
        """Unit test for Vector3.__div__()"""
        v1 = ogre.Vector3(1, 2, 3)
        self.failUnless(v1/2 == (0.5, 1, 3.0/2.0))

    def test___eq__(self):
        """Unit test for Vector3.__eq__()"""
        v1 = ogre.Vector3(1, 2, 3)
        v2 = ogre.Vector3(1, 2, 3)
        self.failUnless(v1 == v2)

    def test___getitem__(self):
        """Unit test for Vector3.__getitem__()"""
        v = ogre.Vector3(1, 2, 3)
        self.failUnless(v[0] == 1.0 and v[1] == 2.0 and v[2] == 3.0)
        self.assertRaises(IndexError, badIndex, v, 3)
        # Python 2.4 raises TypeError for an unsigned long == -1
        self.assertRaises((IndexError, TypeError), badLowerIndex, v)

    def test___gt__(self):
        """Unit test for Vector3.__gt__()"""
        v1 = ogre.Vector3(1, 2, 3)
        v2 = ogre.Vector3(4, 5, 6)
        self.failUnless(v2 > v1)
        
    def test___iadd__(self):
        """Unit test for Vector3.__iadd__()"""
        v1 = ogre.Vector3(1, 2, 3)
        v1 += ogre.Vector3(4, 5, 6)
        self.failUnless(v1 == (5, 7, 9))
        
    def test___idiv__(self):
        """Unit test for Vector3.__idiv__()"""
        v1 = ogre.Vector3(1, 2, 3)
        v1 /= 2
        self.failUnless(v1 == (0.5, 1, 3.0/2.0))

    def test___imul__(self):
        """Unit test for Vector3.__imul__()"""
        v1 = ogre.Vector3(1, 2, 3)
        v1 *= 2
        self.failUnless(v1 == (2, 4, 6))

    def test___init__(self):
        """Unit test for Vector3.__init__()"""
        v = ogre.Vector3()
        self.failUnlessOwned(v)

        v = ogre.Vector3(0, 1, -1)
        self.failUnlessOwned(v)
        self.failUnless(v == (0, 1, -1))

        v = ogre.Vector3(0.0, 1.0, -1.0)
        self.failUnlessOwned(v)
        self.failUnless(v == (0.0, 1.0, -1.0))

        v = ogre.Vector3(1, 2, 3)
        r = ogre.Vector3(v)
        self.failUnlessOwned(v)
        self.failUnless(r == (1, 2, 3))
        self.failIf(issame(v, r))

    def test___isub__(self):
        """Unit test for Vector3.__isub__()"""
        v1 = ogre.Vector3(1, 2, 3)
        v1 -= ogre.Vector3(4, 5, 6)
        self.failUnless(v1 == (-3, -3, -3))

    def test___lt__(self):
        """Unit test for Vector3.__lt__()"""
        v1 = ogre.Vector3(1, 2, 3)
        v2 = ogre.Vector3(4, 5, 6)
        self.failUnless(v1 < v2)

    def test___mul__(self):
        """Unit test for Vector3.__mul__()"""
        v1 = ogre.Vector3(1, 2, 3)
        v2 = ogre.Vector3(4, 5, 6)
        self.failUnless(v1 * v2 == (4, 10, 18))        

    def test___ne__(self):
        """Unit test for Vector3.__ne__()"""
        v1 = ogre.Vector3(1, 2, 3)
        v2 = ogre.Vector3(4, 5, 6)
        self.failUnless(v1 != v2) 

    def test___neg__(self):
        """Unit test for Vector3.__neg__()"""
        v1 = ogre.Vector3(1, 2, 3)
        v2 = -v1
        self.failUnless(v2 == (-1, -2, -3))

    def test___sub__(self):
        """Unit test for Vector3.__sub__()"""
        v1 = ogre.Vector3(1, 2, 3)
        v2 = ogre.Vector3(4, 5, 6)
        self.failUnless(v1 - v2 == (-3, -3, -3))        

    def test_crossProduct(self):
        """Unit test for Vector3.crossProduct()"""
        v1 = ogre.Vector3( 2, -7, 0)
        v2 = ogre.Vector3(-3,  2, 1)
        self.failUnless(v1.crossProduct(v2) == (-7, -2, -17))

    def test_dotProduct(self):
        """Unit test for Vector3.dotProduct()"""
        def dot(x1, y1, x2, y2, z1, z2):
            v1 = ogre.Vector3(x1, y1, z1)
            v2 = ogre.Vector3(x2, y2, z2)
            return v1.dotProduct(v2)    
        self.failUnless(dot(1, 0, 0, 1, 0, 1) == 0)
        self.failUnless(dot(1, 1, 1, 1, 1, 1) == 3)

    def test_getRotationTo(self):
        """Unit test for Vector3.getRotationTo()"""
        v1 = ogre.Vector3(1, 0, 0)
        v2 = ogre.Vector3(0, 1, 0)
        q1 = ogre.Quaternion(0.70710676908493042, 0, 0, 0.70710676908493042)
        self.failUnless(v1.getRotationTo(v2) == q1) 

    def test_length(self):
        """Unit test for Vector3.length"""
        v1 = ogre.Vector3(0, 0, 0)
        v2 = ogre.Vector3(3, 0, 4)
        self.failUnless(v1.length == 0)
        self.failUnless(v2.length == 5)

    def test_makeCeil(self):
        """Unit test for Vector3.makeCeil()"""
        v1 = ogre.Vector3( 2, -7, 0)
        v2 = ogre.Vector3(-3,  2, 1)
        r = v1.makeCeil(v2)
        self.failUnless(r is None)
        self.failUnless(v1 == (2, 2, 1))

    def test_makeFloor(self):
        """Unit test for Vector3.makeFloor()"""
        v1 = ogre.Vector3( 2, -7, 0)
        v2 = ogre.Vector3(-3,  2, 1)
        r = v1.makeFloor(v2)
        self.failUnless(r is None)
        self.failUnless(v1 == (-3, -7, 0))

    def test_midPoint(self):
        """Unit test for Vector3.midPoint()"""
        v1 = ogre.Vector3( 2, -7, 0 )
        v2 = ogre.Vector3( -3, 2, 1 )

        r = v1.midPoint(v2)
        self.failIf(r is None)
        self.failIf(issame(r, v1))
        self.failIf(issame(r, v2))

    def test_normalise(self):
        """Unit test for Vector3.normalise()"""
        v1 = ogre.Vector3(1, 3, -1)
        v2 = v1.normalise()

        self.failIf(v2 is None)
        self.failUnless(abs(v1.squaredLength - 1) < 0.00001)
        self.failIf(issame(v1, v2))

    def test_normalisedCopy(self):
        """Unit test for Vector3.normalisedCopy()"""
        v1 = ogre.Vector3(1, 3, -1)
        v2 = v1.normalisedCopy()

        self.failIf(v2 is None)
        self.failUnless(abs(v2.squaredLength - 1) < 0.0001)
        self.failIf(issame(v1, v2))

    def test_perpendicular(self):
        """Unit test for Vector3.perpendicular()"""
        v1 = ogre.Vector3(1, 0, 0)
        self.failUnless(v1.perpendicular() == (0,0,1))

    def test_randomDeviant(self):
        """Unit test for Vector3.randomDeviant()"""
        v1 = ogre.Vector3(1, 1, 1)
        self.failUnless(v1.randomDeviant(ogre.Radian(1.0)) is not None)

    def test_reflect(self):
        """Unit test for Vector3.reflect()"""
        v1 = ogre.Vector3(1, 1, 1)
        v2 = ogre.Vector3(0, 1, 0)
        self.failUnless(v1.reflect(v2) == (1, -1, 1))
        
    def test_squaredLength(self):
        """Unit test for Vector3.squaredLength"""
        v1 = ogre.Vector3(3, 0, 4)
        self.failUnless(v1.squaredLength == 25)
        
    def test_x(self):
        """Unit test for Vector3.x"""
        v1 = ogre.Vector3(1, 2, 3)
        v1.x = 100
        self.failUnless(v1.x == 100)

    def test_y(self):
        """Unit test for Vector3.y"""
        v1 = ogre.Vector3(1, 2, 3)
        v1.y = 100
        self.failUnless(v1.y == 100)

    def test_z(self):
        """Unit test for Vector3.z"""
        v1 = ogre.Vector3(1, 2, 3)
        v1.z = 100
        self.failUnless(v1.z == 100)

    def x_testStatic(self):
        l = [ (ogre.Vector3( 0, 0, 0 ), ogre.Vector3.ZERO),
              (ogre.Vector3( 1, 0, 0 ), ogre.Vector3.UNIT_X),
              (ogre.Vector3( 0, 1, 0 ), ogre.Vector3.UNIT_Y),
              (ogre.Vector3( 0, 0, 1 ), ogre.Vector3.UNIT_Z),
              (ogre.Vector3( -1, 0, 0 ), ogre.Vector3.NEGATIVE_UNIT_X),
              (ogre.Vector3( 0, -1, 0 ), ogre.Vector3.NEGATIVE_UNIT_Y),
              (ogre.Vector3( 0, 0, -1 ), ogre.Vector3.NEGATIVE_UNIT_Z) ]

        for v, s in l:
            self.failUnless( v == s )
            
            v1 = s
            v1.x += 1
            v1.y += 1

            self.failUnless( v == s )

        v1 = ogre.Vector3.ZERO
        v1.x = 1
        v1.y = 1

        self.failIf( v1 == ogre.Vector3.ZERO )
        self.failUnless( zero == ogre.Vector3.ZERO )

    def test___nonzero__(self):
        """Unit test for Vector3.__nonzero__()"""
        # these are false
        f1 = ogre.Vector3(0, 0, 0)
        f2 = ogre.Vector3(0.0, 0.0, 0.0)

        # these are true
        t1 = ogre.Vector3(1, 2, 3)
        t2 = ogre.Vector3(1, 0, 0)
        t3 = ogre.Vector3(0, 0, 1)

        # Note this tests the boundary condition. The method of testing should
        # be at most this accurate, and evaluate this to true:
        t4 = ogre.Vector3(0.00001, 0, 0)

        self.failIf(f1)
        self.failIf(f2)

        self.failUnless(t1)
        self.failUnless(t2)
        self.failUnless(t3)
        self.failUnless(t4)

    def test_inplaceCrash(self):
	"""Test for segfaults in inplace operators."""
	x = ogre.Vector3(0, 0, 0)
	v = ogre.Vector3(1, 1, 1)
	w = v
	v += x ; v *= 2
	w += x ; w /= 2
	del v
	del w
    
    def test_directionEquals(self):
        """Unit test for Vector3.directionEquals()"""
        self.failUnless(ogre.Vector3(1,1,1).directionEquals(
            ogre.Vector3(2,2,2.001), ogre.Radian(0.01)))

    def test_positionEquals(self):
        """Unit test for Vector3.positionEquals()"""
        self.failUnless(
            ogre.Vector3(1, 1, 1).positionEquals(
                ogre.Vector3(1.01, 1.02, 1.03), 0.1))
	
if __name__ == '__main__':
    unittest.main()
	    
