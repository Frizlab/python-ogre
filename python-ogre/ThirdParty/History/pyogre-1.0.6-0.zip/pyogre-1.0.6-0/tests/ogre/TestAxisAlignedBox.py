# Unit tests for AxisAlignedBox
#
# Copyright (C) 2005 PyOgre Core Team
# 
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
# 
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
# 
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
from helpers import *
import BaseTestAxisAlignedBox

class AxisAlignedBoxTests(BaseTestAxisAlignedBox.AxisAlignedBoxTests, TestCase):
    """Test cases for AxisAlignedBox."""

    def test___init__(self):
        """Unit test for AxisAlignedBox.__init__()"""
	aab = ogre.AxisAlignedBox()
        self.failUnlessOwned(aab)

        aab = ogre.AxisAlignedBox(ogre.Vector3(0, 0, 1), ogre.Vector3(2, 2, 2))
        self.failUnlessOwned(aab)
        self.failUnless(aab.minimum == ogre.Vector3(0, 0, 1))
        self.failUnless(aab.maximum == ogre.Vector3(2, 2, 2))

        aab = ogre.AxisAlignedBox(0, 0, 1, 2, 2, 2)
        self.failUnlessOwned(aab)
        self.failUnless(aab.minimum == ogre.Vector3(0, 0, 1))
        self.failUnless(aab.maximum == ogre.Vector3(2, 2, 2))

        aab2 = ogre.AxisAlignedBox(aab)
        self.failUnlessOwned(aab2)
        self.failUnless(aab.minimum == aab2.minimum)
        self.failUnless(aab.maximum == aab2.maximum)
        self.failIf(issame(aab, aab2))

    def test___nonzero__(self):
        """Unit test for AxisAlignedBox.__nonzero__()"""
        aab = ogre.AxisAlignedBox()
        self.failIf(aab)

        aab = ogre.AxisAlignedBox(0, 0, 1, 2, 2, 2)
        self.failUnless(aab)

        aab.setNull()
        self.failIf(aab)

    def test_setExtents(self):
        """Unit test for AxisAlignedBox.setExtents()"""
        aab = ogre.AxisAlignedBox(ogre.Vector3(0, 1, 2), ogre.Vector3(3, 4, 5))
        
        aab.setExtents(ogre.Vector3(-1, 0, 1), ogre.Vector3(2, 3, 4))
        self.failUnless(aab.minimum == ogre.Vector3(-1, 0, 1))
        self.failUnless(aab.minimum == (-1, 0, 1))
        self.failUnless(aab.maximum == ogre.Vector3(2, 3, 4))
        self.failUnless(aab.maximum == (2, 3, 4))

        aab.setExtents((-1, 0, 1), (2, 3, 4))
        self.failUnless(aab.minimum == ogre.Vector3(-1, 0, 1))
        self.failUnless(aab.minimum == (-1, 0, 1))
        self.failUnless(aab.maximum == ogre.Vector3(2, 3, 4))
        self.failUnless(aab.maximum == (2, 3, 4))

    def test_setNull(self):
        """Unit test for AxisAlignedBox.setNull()"""
        aab = ogre.AxisAlignedBox()
        self.failIf(aab)

        aab = ogre.AxisAlignedBox(0, 0, 1, 2, 2, 2)
        self.failUnless(aab)

        aab.setNull()
        self.failIf(aab)


    def test_transform(self):
        """Unit test for AxisAlignedBox.transform()"""
        self.fail('test case not implemented')

    def test_maximum(self):
        """Unit test for AxisAlignedBox.maximum"""
        aab = ogre.AxisAlignedBox(ogre.Vector3(0, 1, 2), ogre.Vector3(3, 4, 5))
        self.failUnless(aab.maximum == ogre.Vector3(3, 4, 5))
        self.failUnless(aab.maximum == (3, 4, 5))

        aab.maximum = ogre.Vector3(0, 1, 2)
        self.failUnless(aab.maximum == ogre.Vector3(0, 1, 2))
        self.failUnless(aab.maximum == (0, 1, 2))


        
    def test_minimum(self):
        """Unit test for AxisAlignedBox.minimum"""
        aab = ogre.AxisAlignedBox(ogre.Vector3(0, 1, 2), ogre.Vector3(3, 4, 5))
        self.failUnless(aab.minimum == ogre.Vector3(0, 1, 2))
        self.failUnless(aab.minimum == (0, 1, 2))

        aab.minimum = ogre.Vector3(-3, -4, -5)
        self.failUnless(aab.minimum == ogre.Vector3(-3, -4, -5))
        self.failUnless(aab.minimum == (-3, -4, -5))


    def test_volume(self):
        def volumeError():
            aab.volume = 2
        """Unit test for AxisAlignedBox.volume"""
        aab = ogre.AxisAlignedBox(0, 0, 0, 1, 1, 1)
        
        self.failUnless(aab.volume == 1)
        #self.assertRaises(AttributeError, volumeError)
