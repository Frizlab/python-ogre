# Unit tests for Matrix3 and Matrix4
#
# Copyright (C) 2005 PyOgre Core Team
# 
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
# 
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
# 
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import localogre as ogre
from helpers import issame
from unittest import TestCase

def cmp3(m, *values):
    for row in range(3):
        for col in range(3):
            if m.Get(row, col) != values[row*3 + col]:
                return False
    return True

class Matrix3Tests(TestCase):
    
    def testCtors(self):
	"""Test constructors."""
	m = ogre.Matrix3()
        self.failUnless(m.thisown == 1)

        m = ogre.Matrix3(0, 0, 0, 1, 1, 1, 2, 2, 2)
        self.failUnless(m.thisown == 1)
        self.failUnless(cmp3(m, 0, 0, 0, 1, 1, 1, 2, 2, 2))

        m = ogre.Matrix3(0, 0, 0, 1, 1, 1, 2, 2, 2)
        r = ogre.Matrix3(m)
        self.failUnless(r.thisown == 1)
        self.failUnless(cmp3(r, 0, 0, 0, 1, 1, 1, 2, 2, 2))
                         
    def testIndex(self):
	"""Test index use."""
        m = ogre.Matrix3(0, 0, 0, 1, 1, 1, 2, 2, 2)

        v = m[0]
        self.failUnless(v.thisown == 1)
        self.failUnless(v == (0,0,0))

        self.failUnless(m[1] == (1, 1, 1))
        self.failUnless(m[2] == (2, 2, 2))

        m.Set(1, 1, 3)
        m.SetRow(0, ogre.Vector3(1, 1, 1))
        m.SetColumn(2, (3, 3, 3))
        
        self.failUnless(m.Get(0, 2) == 3)
        self.failUnless(m.GetRow(1) == (1, 3, 3))
        self.failUnless(m.GetColumn(1) == ogre.Vector3(1, 3, 2))
        
        #self.assertRaises(IndexError, badIndex, v, 2)
        #self.assertRaises(IndexError, badLowerIndex, v)

    def testCopy(self):
	"""Test copy."""
        m1 = ogre.Matrix3(0, 0, 0, 0, 0, 0, 0, 0, 0)
        m2 = ogre.Matrix3(0, 0, 0, 1, 1, 1, 2, 2, 2)

        m2.copy(m1)
        self.failUnless(m1 == m2)
        self.failIf(issame(m1, m2))

        m3 = ogre.Matrix3(m1)
        self.failUnless(m1 == m3)
        self.failIf(issame(m1, m3))
        
    ## def testOps(self):
    ##     """Test various operators."""
    ##     v1 = ogre.Vector2(1, 2)

    ##     v2 = ogre.Vector2(1, 2)
    ##     self.failUnless(v1 == v2)

    ##     v2 = ogre.Vector2(3, 4)
    ##     self.failUnless(v1 != v2)

    ##     self.failUnless(v1 < v2)
    ##     self.failUnless(v2 > v1)
        
    ##     r = v1 + v2
    ##     self.failUnless(r.thisown == 1)
    ##     self.failUnless(cp2(r, 4.0, 6.0))

    ##     r = v1 - v2
    ##     self.failUnless(r.thisown == 1)
    ##     self.failUnless(cp2(r, -2.0, -2.0))

    ##     r = v1 * 2 # note that '2' is a scalar here
    ##     self.failUnless(r.thisown == 1)
    ##     self.failUnless(cp2(r, 2.0, 4.0))

    ##     r = v1 / 2 # note that '2' is a scalar here
    ##     self.failUnless(r.thisown == 1)
    ##     self.failUnless(cp2(r, 0.5, 1.0))

    ##     r = v1 * v2 # note that 'v2' is a vector here
    ##     self.failUnless(r.thisown == 1)
    ##     self.failUnless(cp2(r, 3.0, 8.0))

    ## def testReference(self):
    ##     """Test reference count, garbage collection and C own/disown."""
    ##     v1 = ogre.Vector2(1, 2)
        
    ##     r = v2 = ogre.Vector2(3, 4)
    ##     r += v1
    ##     self.failUnless(issame(r, v2))
    ##     self.failUnless(cp2(r, 4.0, 6.0))

    ##     r = v2 = ogre.Vector2(3, 4)
    ##     r -= v1
    ##     self.failUnless(issame(r, v2))
    ##     self.failUnless(cp2(r, 2.0, 2.0))

    ##     r = v2 = ogre.Vector2(3, 4)
    ##     r *= 2
    ##     self.failUnless(issame(r, v2))
    ##     self.failUnless(cp2(r, 6.0, 8.0))        
        
    ##     r = v2 = ogre.Vector2(3, 4)
    ##     r /= 2
    ##     self.failUnless(issame(r, v2))
    ##     self.failUnless(cp2(r, 1.5, 2.0))

    ## ## test functions ##
    
    ## def testLength(self):
    ##     v1 = ogre.Vector2(0, 0)
    ##     v2 = ogre.Vector2(3, 4)

    ##     self.failUnless(v1.length() == 0)
    ##     self.failUnless(v2.length() == 5)
    ##     self.failUnless(v2.squaredLength() == 25)

    ## def testDotProduct(self):
    ##     def dot(x1, y1, x2, y2):
    ##         v1 = ogre.Vector2(x1, y1)
    ##         v2 = ogre.Vector2(x2, y2)
    ##         return v1.dotProduct(v2)
        
    ##     self.failUnless(dot(1, 0, 0, 1) == 0)
    ##     self.failUnless(dot(1, 0, 1, 0) == 1)

    ## def testNormalise(self):
    ##     v1 = ogre.Vector2(1, 3)
    ##     v2 = v1.normalise()
    ##     self.failUnless(v1.squaredLength() == 1)
    ##     self.failIf(issame(v1, v2))

    ## def testMidpoint(self):
    ##     v1 = ogre.Vector2(2, -7)
    ##     v2 = ogre.Vector2(-3, 2)
        
    ##     tmp = v1.midPoint(v2)
    ##     self.failIf(tmp is None)
    ##     self.failIf(issame(tmp, v1))
    ##     self.failIf(issame(tmp, v2))

    ## def testFloor(self):
    ##     v1 = ogre.Vector2(2, -7)
    ##     v2 = ogre.Vector2(-3, 2)

    ##     tmp = v1.makeFloor(v2)
    ##     self.failIf(tmp is None)
    ##     self.failUnless(cp2(tmp, -3, -7))

    ## def testCeil(self):
    ##     v1 = ogre.Vector2(2, -7)
    ##     v2 = ogre.Vector2(-3, 2)

    ##     tmp = v1.makeCeil(v2)
    ##     self.failIf(tmp is None)
    ##     self.failUnless(cp2(tmp, 2, 2))

    ## def testPerpendicular(self):
    ##     v1 = ogre.Vector2(2, -7)
    ##     v2 = ogre.Vector2(-3, 2)
        
    ##     self.failIf(v1.perpendicular() is None)

    ## def testCrossProduct(self):
    ##     v1 = ogre.Vector2(2, -7)
    ##     v2 = ogre.Vector2(-3, 2)

    ##     self.failIf(v1.crossProduct(v2) is None)
        
    ## def testZeroLength(self):
    ##     v1 = ogre.Vector2(2, -7)
    ##     zero = ogre.Vector2(ogre.Vector2.ZERO)

    ##     self.failIf(v1.isZeroLength() is None)
    ##     self.failIf(v1.isZeroLength())
    ##     self.failUnless(zero.isZeroLength())
    
    ## ## test static members ##

    ## def testStatic(self):
    ##     l = [(ogre.Vector2( 0, 0), ogre.Vector2.ZERO),
    ##          (ogre.Vector2( 1, 0), ogre.Vector2.UNIT_X),
    ##          (ogre.Vector2( 0, 1), ogre.Vector2.UNIT_Y),
    ##          (ogre.Vector2(-1, 0), ogre.Vector2.NEGATIVE_UNIT_X),
    ##          (ogre.Vector2( 0,-1), ogre.Vector2.NEGATIVE_UNIT_Y)]

    ##     for v, s in l:
    ##         self.failUnless(v == s)
            
    ##         v1 = s
    ##         v1.x += 1
    ##         v1.y += 1
	    
    ##         self.failUnless(v == s)

    ##     v1 = ogre.Vector2.ZERO
    ##     v1.x = 1
    ##     v1.y = 1

    ##     self.failIf(v1 == ogre.Vector2.ZERO)
    ##     self.failUnless(zero == ogre.Vector2.ZERO)

