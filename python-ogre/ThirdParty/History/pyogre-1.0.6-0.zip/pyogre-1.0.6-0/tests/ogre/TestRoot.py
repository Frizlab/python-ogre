# TestRoot.py - unit tests for the Root class
#
# Copyright (C) 2005 PyOgre Core Team
# 
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
# 
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
# 
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

from helpers import *
import BaseTestRoot

class FLTestStarted(ogre.FrameListener):
    def __init__(self):
        ogre.FrameListener.__init__(self)

    def frameStarted(self, evt):
        return False


class FLTestEnded(ogre.FrameListener):
    def __init__(self):
        ogre.FrameListener.__init__(self)

    def frameEnded(self, evt):
        return False


class RootTests(TestCase, BaseTestRoot.RootTests):
    
    def test___init__(self):
        """Unit test for __init__()"""
        root1 = ogre.Root()
        root2 = ogre.Root.getSingleton()
        self.failUnlessOwned(root1)
        self.failIfOwned(root2)
        self.failUnless(issame(root1, root2))

    def test__fireFrameEnded(self):
        """Unit test for Root._fireFrameEnded()"""
        # create Root, dummy FrameEvent
        root = ogre.Root()
        fe = ogre.FrameEvent()

        # create the FrameListeners, make sure they do what we expect
        start = FLTestStarted()
        self.failIf(start.frameStarted(fe))
        self.failUnless(start.frameEnded(fe))

        end = FLTestEnded()
        self.failUnless(end.frameStarted(fe))
        self.failIf(end.frameEnded(fe))

        # add first FrameListener
        root.addFrameListener(start)
        self.failUnless(root._fireFrameEnded(fe))

        # add second frame listener
        root.addFrameListener(end)
        self.failIf(root._fireFrameEnded(fe))

        # remove first frame listener
        root.removeFrameListener(start)
        self.failIf(root._fireFrameEnded(fe))

        # remove second frame listener
        root.removeFrameListener(end)
        self.failUnless(root._fireFrameEnded(fe))

        del root
        
    def test__fireFrameStarted(self):
        """Unit test for Root._fireFrameStarted()"""
        # create Root, dummy FrameEvent
        root = ogre.Root()
        fe = ogre.FrameEvent()

        # create the FrameListeners
        start = FLTestStarted()
        self.failIf(start.frameStarted(fe))

        end = FLTestEnded()
        self.failUnless(end.frameStarted(fe))

        # add first FrameListener
        root.addFrameListener(start)
        self.failIf(root._fireFrameStarted(fe))

        # add second frame listener
        root.addFrameListener(end)
        self.failIf(root._fireFrameStarted(fe))

        # remove first frame listener
        root.removeFrameListener(start)
        self.failUnless(root._fireFrameStarted(fe))

        # remove second frame listener
        root.removeFrameListener(end)
        self.failUnless(root._fireFrameStarted(fe))

        del root

    def test_addFrameListener(self):
        """Unit test for Root.addFrameListener()"""
        # create Root, dummy FrameEvent
        root = ogre.Root()
        fe = ogre.FrameEvent()

        # create the FrameListeners
        start = FLTestStarted()
        self.failIf(start.frameStarted(fe))
        self.failUnless(start.frameEnded(fe))

        end = FLTestEnded()
        self.failUnless(end.frameStarted(fe))
        self.failIf(end.frameEnded(fe))

        # add first FrameListener
        root.addFrameListener(start)

        self.failIf(root._fireFrameStarted(fe))
        self.failUnless(root._fireFrameEnded(fe))

        # add second frame listener
        root.addFrameListener(end)
        self.failIf(root._fireFrameStarted(fe))
        self.failIf(root._fireFrameEnded(fe))

        # remove first frame listener
        root.removeFrameListener(start)
        self.failUnless(root._fireFrameStarted(fe))
        self.failIf(root._fireFrameEnded(fe))

        # remove second frame listener
        root.removeFrameListener(end)
        self.failUnless(root._fireFrameStarted(fe))
        self.failUnless(root._fireFrameEnded(fe))

        del root

    def test_removeFrameListener(self):
        """Unit test for Root.removeFrameListener()"""
        # create Root, dummy FrameEvent
        root = ogre.Root()
        fe = ogre.FrameEvent()

        # create the FrameListeners
        start = FLTestStarted()
        self.failIf(start.frameStarted(fe))
        self.failUnless(start.frameEnded(fe))

        end = FLTestEnded()
        self.failUnless(end.frameStarted(fe))
        self.failIf(end.frameEnded(fe))

        # add first FrameListener
        root.addFrameListener(start)

        self.failIf(root._fireFrameStarted(fe))
        self.failUnless(root._fireFrameEnded(fe))

        # add second frame listener
        root.addFrameListener(end)
        self.failIf(root._fireFrameStarted(fe))
        self.failIf(root._fireFrameEnded(fe))

        # remove first frame listener
        root.removeFrameListener(start)
        self.failUnless(root._fireFrameStarted(fe))
        self.failIf(root._fireFrameEnded(fe))

        # remove second frame listener
        root.removeFrameListener(end)
        self.failUnless(root._fireFrameStarted(fe))
        self.failUnless(root._fireFrameEnded(fe))

        del root

    def test_showConfigDialog(self):
        """Unit test for Root.showConfigDialog()"""
        # a unit test cannot be written for this really, but the proof of it
        # working should be obvious.  Otherwise none of the demos would work
