# Unit tests for ConfigFile
# 
# Copyright (C) 2005 PyOgre Core Team
# 
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
# 
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
# 
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

from helpers import *
import BaseTestConfigFile

class ConfigFileTests(TestCase, BaseTestConfigFile.ConfigFileTests):
    """Test cases for ConfigFile."""

    FROM_FILE = 'TestConfigFile_resources.cfg'

    # some tests require an initialized Ogre environment (i.e., Root())
    root = None
    
    def setUp(self):
        if self.root is None:
            self.root = ogre.Root()

    def tearDown(self):
        if self.root:
            self.root = None
            
    def test___init__(self):
        """Unit test for ConfigFile.__init__()"""
        cf = ogre.ConfigFile()
        self.failUnlessOwned(cf)

    def test_clear(self):
        """Unit test for ConfigFile.clear()"""
        cf = ogre.ConfigFile()
        cf.loadFromFile(self.FROM_FILE)
        cf.clear()

    def test_getMultiSetting(self):
        """Unit test for ConfigFile.getMultiSetting()"""
        cf = ogre.ConfigFile()
        cf.loadFromFile(self.FROM_FILE)
        self.failUnless(len(cf.getMultiSetting('FileSystem', 'General')) == 3)
        self.failUnless(len(cf.getMultiSetting('Zip', 'General')) == 1)
        self.failUnless(len(cf.getMultiSetting('Zip', 'Bootstrap')) == 2)
        
    def test_getSectionIterator(self):
        """Unit test for ConfigFile.getSectionIterator()"""
        cf = ogre.ConfigFile()
        cf.loadFromFile(self.FROM_FILE)
        seci = cf.getSectionIterator()
        self.failUnlessOwned(seci)

        # test the three sections (including BLANK empty section)
        secn = 0
        for secname, mm in seci:
            secn += 1
            # FIXME: std wrapped not owned because part of multimap?
            self.failIfOwned(mm)
        self.failUnless(secn == 3)
        
    def test_getSetting(self):
        """Unit test for ConfigFile.getSetting()"""
        cf = ogre.ConfigFile()
        cf.loadFromFile(self.FROM_FILE)
        self.failUnless(cf.getSetting('FileSystem', 'General') == 'Path')
        self.failUnless(cf.getSetting('Zip', 'General') == 'AZipFile.zip')
        self.failUnless(cf.getSetting('Zip', 'Bootstrap') == 'AZipFile.zip')

    def test_getSettingsIterator(self):
        """Unit test for ConfigFile.getSettingsIterator()"""
        cf = ogre.ConfigFile()
        cf.loadFromFile(self.FROM_FILE)
        for secname, mm in cf.getSectionIterator():
            seti = cf.getSettingsIterator(secname)
            self.failUnlessOwned(seti)
            if mm: # this is needed by swif flawed __iter__ implementation
                values = list(mm.values())
                for setf, setn in seti:
                    self.failUnless(setn in values)
                    values.remove(setn)
                self.failUnless(len(values) == 0)
        
    def test_loadFromFile(self):
        """Unit test for ConfigFile.loadFromFile()"""
        cf = ogre.ConfigFile()
        cf.loadFromFile(self.FROM_FILE)
