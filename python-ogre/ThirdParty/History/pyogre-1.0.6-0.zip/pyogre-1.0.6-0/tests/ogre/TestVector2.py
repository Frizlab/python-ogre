# Unit tests for Vector2
# 
# Copyright (C) 2005 PyOgre Core Team
# 
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
# 
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
# 
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

from helpers import *
import BaseTestVector2

class Vector2Tests(TestCase, BaseTestVector2.Vector2Tests):
    def test___init__(self):
        """Unit test for Vector2.__init__()"""
        v = ogre.Vector2()
        self.failUnless(v.thisown == 1)

        v = ogre.Vector2(0, 1)
        self.failUnless(v.thisown == 1)
        self.failUnless(cp2(v, 0.0, 1.0))

        v = ogre.Vector2(0.0, 1.0)
        self.failUnless(v.thisown == 1)
        self.failUnless(cp2(v, 0.0, 1.0))

        v = ogre.Vector2(1, 2)
        r = ogre.Vector2(v)
        self.failUnless(r.thisown == 1)
        self.failUnless(cp2(r, 1.0, 2.0))

        # test tuple expansion
        v = ogre.Vector2(1, 2)
        self.failUnless(v == (1, 2))
        self.failUnless(v == ogre.Vector2(1, 2))
                         
    def test___getitem__(self):
        """Unit test for Vector2.__getitem__()"""
        v = ogre.Vector2(1, 2)
        self.failUnless(v[0] == 1.0 and v[1] == 2.0)

    def test___eq__(self):
        """Unit test for Vector2.__eq__()"""
        v1 = ogre.Vector2(1, 2)
        v2 = ogre.Vector2(1, 2)
        
        self.failUnless(v1 == v2)

    def test___ne__(self):
        """Unit test for Vector2.__neq__()"""
        v1 = ogre.Vector2(1, 2)
        v2 = ogre.Vector2(3, 4)
        self.failUnless(v1 != v2)
        
    def test___gt__(self):
        """Unit test for Vector2.__gt__()"""
        v1 = ogre.Vector2(1, 2)
        v2 = ogre.Vector2(3, 4)

        self.failUnless(v2 > v1)
        self.failIf(v1 > v2)

    def test___lt__(self):
        """Unit test for Vector2.__lt__()"""
        v1 = ogre.Vector2(1, 2)
        v2 = ogre.Vector2(3, 4)

        self.failUnless(v1 < v2)
        self.failIf(v2 < v1)

    def test___add__(self):
        """Unit test for Vector2.__add__()"""
        v1 = ogre.Vector2(1, 2)
        v2 = ogre.Vector2(3, 4)
        
        r = v1 + v2
        self.failUnless(r.thisown == 1)
        self.failUnless(cp2(r, 4.0, 6.0))

    def test___iadd__(self):
        """Unit test for Vector2.__iadd__()"""
        v1 = ogre.Vector2(1, 2)
        v2 = ogre.Vector2(3, 4)
        
        v1 += v2
        self.failUnless(v1.thisown == 1)
        self.failUnless(cp2(v1, 4.0, 6.0))

    def test___sub__(self):
        """Unit test for Vector2.__sub__()"""
        v1 = ogre.Vector2(1, 2)
        v2 = ogre.Vector2(3, 4)

        r = v1 - v2
        self.failUnless(r.thisown == 1)
        self.failUnless(cp2(r, -2.0, -2.0))
        
        
    def test___isub__(self):
        """Unit test for Vector2.__isub__()"""
        v1 = ogre.Vector2(1, 2)
        v2 = ogre.Vector2(3, 4)

        v1 -= v2
        self.failUnless(v1.thisown == 1)
        self.failUnless(cp2(v1, -2.0, -2.0))

    def test___mul__(self):
        """Unit test for Vector2.__mul__()"""
        v1 = ogre.Vector2(1, 2)
        v2 = ogre.Vector2(3, 4)

        r = v1 * 2 # note that '2' is a scalar here
        self.failUnless(r.thisown == 1)
        self.failUnless(cp2(r, 2.0, 4.0))

        v1 = ogre.Vector2(1, 2)
        r = v1 * v2 # note that 'v2' is a vector here
        self.failUnless(r.thisown == 1)
        self.failUnless(cp2(r, 3.0, 8.0))


    def test___imul__(self):
        """Unit test for Vector2.__imul__()"""
        v1 = ogre.Vector2(1, 2)
        v2 = ogre.Vector2(3, 4)

        v1 *= 2 # note that '2' is a scalar here
        self.failUnless(v1.thisown == 1)
        self.failUnless(cp2(v1, 2.0, 4.0))

    def test___div__(self):
        """Unit test for Vector2.__div__()"""
        v1 = ogre.Vector2(1, 2)
        v2 = ogre.Vector2(3, 4)

        r = v1 / 2 # note that '2' is a scalar here
        self.failUnless(r.thisown == 1)
        self.failUnless(cp2(r, 0.5, 1.0))        

    def test___idiv__(self):
        """Unit test for Vector2.__idiv__()"""
        v1 = ogre.Vector2(1, 2)
        v2 = ogre.Vector2(3, 4)

        v1 /= 2 # note that '2' is a scalar here
        self.failUnless(v1.thisown == 1)
        self.failUnless(cp2(v1, 0.5, 1.0))

    def test_length(self):
        """Unit test for Vector2.length"""
        v1 = ogre.Vector2(0, 0)
        v2 = ogre.Vector2(3, 4)

        self.failUnless(v1.length == 0)
        self.failUnless(abs(v2.length - 5) < 0.0001)

    def test_squaredLength(self):
        """Unit test for Vector2.squaredLength"""
        v1 = ogre.Vector2(0, 0)
        v2 = ogre.Vector2(3, 4)

        self.failUnless(v1.squaredLength == 0)
        self.failUnless(abs(v2.squaredLength - 25) < 0.0001)
        
    def test_dotProduct(self):
        """Unit test for Vector2.dotProduct()"""
        def dot(x1, y1, x2, y2):
            v1 = ogre.Vector2(x1, y1)
            v2 = ogre.Vector2(x2, y2)
            return v1.dotProduct(v2)
        
        self.failUnless(dot(1, 0, 0, 1) == 0)
        self.failUnless(dot(1, 0, 1, 0) == 1)
        self.failUnless(dot(2, 4, 3, 5) == 26)

    def test_normalise(self):
        """Unit test for Vector2.normalise()"""
        v1 = ogre.Vector2(1, 3)
        v2 = v1.normalise()
        self.failUnless(abs(v1.squaredLength - 1) < 0.00001)
        self.failIf(issame(v1, v2))

    def test_midPoint(self):
        """Unit test for Vector2.midPoint()"""
        v1 = ogre.Vector2(2, -7)
        v2 = ogre.Vector2(-4, 3)

        tmp = v1.midPoint(v2)
        self.failUnless(tmp == (-1, -2))
        self.failIf(issame(tmp, v1))
        self.failIf(issame(tmp, v2))

    def test_makeFloor(self):
        """Unit test for Vector2.makeFloor()"""
        v1 = ogre.Vector2(2, -7)
        v2 = ogre.Vector2(-3, 2)

        v1.makeFloor(v2)
        self.failUnless(v1.x == -3 and v1.y == -7)

    def test_makeCeil(self):
        """Unit test for Vector2.makeCeil()"""
        v1 = ogre.Vector2(2, -7)
        v2 = ogre.Vector2(-3, 2)

        v1.makeCeil(v2)
        self.failUnless(v1.x == 2 and v1.y == 2)

    def test_perpendicular(self):
        """Unit test for Vector2.perpendicular()"""
        v1 = ogre.Vector2(2, -7)
        v2 = ogre.Vector2(-3, 2)
        
        self.failIf(v1.perpendicular() is None)

    def test_crossProduct(self):
        """Unit test for Vector2.crossProduct()"""
        v1 = ogre.Vector2(2, -7)
        v2 = ogre.Vector2(-3, 2)

        self.failIf(v1.crossProduct(v2) is None)

    def test___neg__(self):
        """Unit test for Vector2.__neg__()"""
        v1 = ogre.Vector2(2, -7)
        v2 = ogre.Vector2(-3, 2)

        self.failUnless(-v1 == (-2, 7))
        self.failUnless(-v2 == (3, -2))
        
    def test_x(self):
        """Unit test for Vector2.x"""
        v1 = ogre.Vector2(1, 2)
        self.failUnless(v1.x == 1)

        v1.x = -3
        self.failUnless(v1.x == -3)

        v1.x += 1
        self.failUnless(v1.x == -2)

    def test_y(self):
        """Unit test for Vector2.y"""
        v1 = ogre.Vector2(1, 2)
        self.failUnless(v1.y == 2)

        v1.y = 3
        self.failUnless(v1.y == 3)

        v1.y += 1
        self.failUnless(v1.y == 4)

    def test___nonzero__(self):
        """Unit test for Vector2.__nonzero__()"""
        v1 = ogre.Vector2(0, 0)
        v2 = ogre.Vector2(1, 0)
        v3 = ogre.Vector2(0, 1)

        self.failIf(v1)
        self.failUnless(v2)
        self.failUnless(v3)

    def test_normalisedCopy(self):
        """Unit test for Vector2.normalisedCopy()"""
        v1 = ogre.Vector2(1, 3)
        v2 = v1.normalisedCopy()

        self.failIf(v2 is None)
        self.failUnless(abs(v2.squaredLength - 1) < 0.0001)
        self.failIf(issame(v1, v2))

    def test_reflect(self):
        """Unit test for Vector2.reflect()"""
        v1 = ogre.Vector2(1, 1)
        v2 = ogre.Vector2(0, 1)
        self.failUnless(v1.reflect(v2) == (1, -1))
        
    def test_randomDeviant(self):
        """Unit test for Vector2.randomDeviant()"""
        v1 = ogre.Vector2(1, 1)

        # This is an inconsitancy in the ogre api.  This should be
        # v1.randomDeviant(ogre.Radian(1.0)).
        self.failUnless(v1.randomDeviant(1.0) is not None)

    def test_inplaceCrash(self):
	"""Test for segfaults in inplace operators."""
	x = ogre.Vector2(0, 0)
	v = ogre.Vector2(1, 1)
	w = v
	v += x
	w += x
	del v
	del w

if __name__ == '__main__':
    unittest.main()
