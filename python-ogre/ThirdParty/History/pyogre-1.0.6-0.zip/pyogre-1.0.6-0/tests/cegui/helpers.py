# helpers.py - Helper functions for unit tests
#
# Copyright (C) 2005 PyOgre Core Team
# 
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
# 
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
# 
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
# USA

import sys
import re
import os
import os.path
import unittest

from pyogre import ogre


def issame(v1, v2):
    """Uses repr() and SWIG type encodings to check for identity."""
    m1 = re.search('instance at ([_0-9a-zA-Z]+)>', repr(v1))
    m2 = re.search('instance at ([_0-9a-zA-Z]+)>', repr(v2))
    if m1 and m2:
        return m1.group(1) == m2.group(1)


class TestCase(unittest.TestCase):
    """An TestCase implementation scpecialized for Ogre3D tests."""

    def failIfOwned(self, obj):
        """Fails if 'obj' holds a reference to an owned C++ object."""
        self.failIf(obj.thisown == 1)

    def failUnlessOwned(self, obj):
        """Fails if 'obj' holds a reference to a disowned C++ object."""
        self.failIf(obj.thisown == 0)
        
    
def cp2(v, x, y):
    return v.x == x and v.y == y

def cp3(v, x, y, z ):
    return cp2(v, x, y) and v.z == z

def cp4( v, x, y, z, w ):
    return cp3(v, x, y, z) and v.w == w

def badIndex( v, max ):
    x = v[max]
def badLowerIndex( v ):
    x = v[-1]
