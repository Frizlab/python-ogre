class Vertex:
    __semantics = { 'position' : 0,
                    'normal' : 1,
                    'diffuse' : 2,
                    'specular' : 3,
                    'binormal' : 4,
                    'tangent' : 5,
                    'texcoord0' : 6,
                    'texcoord1' : 7,
                    'texcoord2' : 8,
                    'texcoord3' : 9,
                    'texcoord4' : 10,
                    'texcoord5' : 11,
                    'blendweight0' : 12,
                    'blendweight1' : 13,
                    'blendweight2' : 14,
                    'blendweight3' : 15,
                    'blendindex0' : 16,
                    'blendindex1' : 17,
                    'blendindex2' : 18,
                    'blendindex3' : 19 }

    def __getFloat(self, element, size):
        return self.bufferProxy.getFloat(self.index, element, size)
    def __getColour(self, element, size):
        return self.bufferProxy.getColour(self.index, element)
    def __getShort(self, element, size):
        return self.bufferProxy.getShort(self.index, element, size)
    def __getByte(self, element, size):
        return self.bufferProxy.getByte(self.index, element, 4)
    
    __getTable = {  ogre.VET_FLOAT1 : Vertex.__getFloat,
                    ogre.VET_FLOAT2 : Vertex.__getFloat  }
    
    def __getattr__(self, attr):
        if attr in self.__semantics:
            
            return _ogre.VertexProxy_pyGetValue(self, self.__semantics[attr])
        else:
            raise AttributeException, "asdf"
    
    
    def __setattr__(self, attr, value):
        if attr in self.__semantics:
            _ogre.VertexProxy_pySetValue(self, self.__semantics[attr], value)
        else:
            self.__dict__[attr] = value
    
    