#ifndef _PythonConsole_h_
#define _PythonConsole_h_

namespace CEGUI
{
    class Window;
    class Editbox;
    class EventArgs;
};

class PythonConsole
{
public:
    PythonConsole();
    virtual ~PythonConsole();

    virtual void show();
    virtual void hide();

    virtual bool onTextAccepted(const CEGUI::EventArgs &args);
    //virtual bool onCloseWindow(const CEGUI::EventArgs &args);
protected:
    unsigned int mTabLevel;
    bool mInit;

    CEGUI::Window  *mWindow;
    CEGUI::Editbox *mInput;
    CEGUI::Editbox *mOutput;
};

#endif
