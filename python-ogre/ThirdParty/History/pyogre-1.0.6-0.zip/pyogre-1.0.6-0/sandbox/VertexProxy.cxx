#include "VertexProxy.h"
#include <memory.h>




VertexProxy::VertexProxy(Ogre::uint32 index, Ogre::uint32 length,
    VertexBufferProxy *proxy, const Ogre::VertexDeclaration &vd)
    : mIndex(index), mLength(length), mBufferProxy(proxy)
{
    memset(mType, 255, sizeof(mTypes));
    memset(mElement, 255, sizeof(mElement));
    
    int texcoord = 0,
        weight = 0,
        index = 0;
    Ogre::VertexElement *ve = 0;
    size_t count = vd.getElementCount(),
           i;
    
    for (i = 0; i < count; ++i)
    {
        ve = vd.getElement(i);
        switch (ve->getSemantic())
        {
        case Ogre::VES_TEXTURE_COORDINATES:
            mType[Offset_texcoord + texcoord] = i;
            texcoord++;
            break;

        case Ogre::VES_BLEND_WEIGHTS:
            mType[Offset_blendweight + weight] = i;
            weight++;
            break;

        case Ogre::VES_BLEND_INDICES:
            mType[Offset_blendindex + index] = i;
            index++;
            break;

        default:
            mType[lookupTable[ve->getSemantic()]] = i;
            break;
        } // switch

        mElements[i] = ve->getType();
    } // for
} // VertexProxy

PyObject *VertexProxy::pyGetValue(int id)
{
    Ogre::uint32 element = mElement[id];
    switch(mType[id])
    {
    case Ogre::VET_FLOAT1:
        return mBufferProxy->getFloat(mIndex, element, 1);

    case Ogre::VET_FLOAT2:
        return mBufferProxy->getFloat(mIndex, element, 2);
        
    case Ogre::VET_FLOAT3:
        return mBufferProxy->getFloat(mIndex, element, 3);

    case Ogre::COLOUR:
        return mBufferProxy->getColour(mIndex, element);

    case Ogre::VET_SHORT1:
        return mBufferProxy->getShort(mIndex, element, 1);

    case Ogre::VET_SHORT2:
        return mBufferProxy->getShort(mIndex, element, 2);
    
    case Ogre::VET_SHORT3:
        return mBufferProxy->getShort(mIndex, element, 3);

    case Ogre::VET_UBYTE4:
        return mBufferProxy->getByte(mIndex, element, 4);
    }
}


void VertexProxy::pySetValue(int id, PyObject *obj)
{
    Ogre::uint32 element = mElement[id];
    switch(mType[id])
    {
    case Ogre::VET_FLOAT1:

    }
}
