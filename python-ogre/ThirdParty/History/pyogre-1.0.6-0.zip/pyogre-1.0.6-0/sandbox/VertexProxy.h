#ifndef _VertexProxy_h_
#define _VertexProxy_h_

#include <Python.h>
#include <Ogre.h>

#include <vector>
#include <map>

class VertexProxy
{
public:
    VertexProxy(Ogre::uint32 index, Ogre::uint32 length,
        VertexBufferProxy *proxy, const Ogre::VertexDeclaration &vd);
    inline ~VertexProxy() {}


    inline Ogre::uint32 getCurr() const
    { return mCurr; }


    void setCurr(Ogre::uint32 value)
    { mCurr = value; }


    inline Ogre::uint32 __len__() const
    { return mLength; }

    void pySetValue(int id, const Ogre::Vector2 &v);
    void pySetValue(int id, const Ogre::Vector3 &v);
    void pySetValue(int id, const Ogre::Vector4 &v);
    void pySetValue(int id, PyObject *obj);
    PyObject *pyGetValue(int id);
protected:
    const size_t table_size = 20;

    const size_t Offset_position = 0;
    const size_t Offset_normal = 1;
    const size_t Offset_diffuse = 2;
    const size_t Offset_specular = 3;
    const size_t Offset_binormal = 4;
    const size_t Offset_tangent = 5;
    const size_t Offset_texcoord = 6;
    const size_t Offset_blendweight = 12;
    const size_t Offset_blendindex = 16;

    const size_t lookupTable[] = { Offset_position, 0, 0, Offset_normal,
                                   Offset_diffuse, Offset_specular, 0,
                                   Offset_binormal, Offset_tangent };
protected:
    Ogre::uint32 mIndex, mLength;
    VertexBufferProxy *mBufferProxy;

    Ogre::uint32 mElement[table_size];
    Ogre::VertexElementType mType[table_size];
};

#endif
