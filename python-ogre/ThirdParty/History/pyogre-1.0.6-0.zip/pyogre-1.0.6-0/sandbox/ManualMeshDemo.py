# This code is in the Public Domain
import pyogre.ogre as ogre
import SampleFramework as sf
import math

class ManualMeshApplication(sf.Application):
    def _createScene(self):
        ent = self.sceneManager.createEntity("box", "cube.mesh")
        import pdb
        pdb.set_trace()
        self._createMesh()



    def _createMesh(self):
        mesh = ogre.MeshManager.getSingleton().createManual("ColourCube", "General")
        sub = mesh.createSubMesh()

        numVertices = 8
        sizeVertBuff = 2 * 3 * numVertices

        sqrt13 = math.sqrt(1.0/3.0)

        vertices = [
            (-100.0, 100.0, -100.0),
            (-sqrt13, sqrt13, -sqrt13),
            (100.0, 100.0, -100.0),
            (sqrt13, sqrt13, -sqrt13),
            (100.0, -100.0, -100.0),
            (sqrt13, -sqrt13, -sqrt13),
            (-100.0, -100.0, -100.0),
            (-sqrt13, -sqrt13, -sqrt13),
            (-100.0, 100.0, 100.0),
            (-sqrt13, sqrt13, sqrt13),
            (100.0, 100.0, 100.0),
            (sqrt13, sqrt13, sqrt13),
            (100.0, -100.0, 100.0),
            (sqrt13, -sqrt13, sqrt13),
            (-100.0, -100.0, 100.0),
            (-sqrt13, -sqrt13, sqrt13)]


        rs = ogre.Root.getSingleton().renderSystem
        colours = [
            rs.convertColourValue((1, 0, 0)),
            rs.convertColourValue((1, 1, 0)),
            rs.convertColourValue((0, 1, 0)),
            rs.convertColourValue((0, 0, 0)),
            rs.convertColourValue((1, 0, 1)),
            rs.convertColourValue((1, 1, 1)),
            rs.convertColourValue((0, 1, 1)),
            rs.convertColourValue((0, 0, 1))]

        faces = [
            (0,2,3),
            (0,1,2),
            (1,6,2),
            (1,5,6),
            (4,6,5),
            (4,7,6),
            (0,7,4),
            (0,3,7),
            (0,5,1),
            (0,4,5),
            (2,7,3),
            (2,6,7)]

        # vertex data
        mesh.sharedVertexData = ogre.VertexData()
        mesh.sharedVertexData.vertexCount = numVertices

        # first buffer
        vDec = mesh.sharedVertexData.vertexDeclaration
        offset = 0
        
        vDec.addElement(0, offset, ogre.VET_FLOAT3, ogre.VES_POSITION)
        offset += ogre.VertexElement.getTypeSize(ogre.VET_FLOAT3)

        vDec.addElement(0, offset, ogre.VET_FLOAT3, ogre.VES_NORMAL)
        offset += ogre.VertexElement.getTypeSize(ogre.VET_FLOAT3)

        hbm = ogre.HardwareBufferManager.getSingleton()
        vBuff = hbm.createVertexBuffer(offset, mesh.sharedVertexData.vertexCount,
                                       ogre.HardwareBuffer.HBU_STATIC_WRITE_ONLY)

        vBuff.writeData(0, vBuff.sizeInBytes, vertices, True)
        binding = mesh.sharedVertexData.vertexBufferBinding
        binding.setBinding(0, vBuff)

        # second buffer
        offset = 0

        vDec.addElement(1, offset, ogre.VET_COLOUR, ogre.VES_DIFFUSE)
        offset += ogre.VertexElement.getTypeSize(ogre.VET_COLOUR)

        
        
        import pdb
        pdb.set_trace()


if __name__ == '__main__':
    try:
        application = ManualMeshApplication()
        application.go()
    except ogre.OgreException, e:
        print e
