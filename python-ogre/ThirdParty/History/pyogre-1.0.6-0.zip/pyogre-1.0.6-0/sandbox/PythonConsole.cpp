#include "PythonConsole.h"

#include <CEGUI.h>
#include <elements/CEGUIEditBox.h>

#define BIND_CEGUI_EVENT(window, event, method) window->subscribeEvent(event, CEGUI::Event::Subscriber(&method, this)); 

PythonConsole::PythonConsole()
: mTabLevel(0), mInit(false), mWindow(0), mInput(0), mOutput(0)
{
}


PythonConsole::~PythonConsole()
{
}

void PythonConsole::show()
{
    if (!mInit)
    {
        mWindow = CEGUI::WindowManager::getSingleton().loadWindowLayout("pyconsole.xml");
        assert(mWindow);
        if (mWindow)
        {
            CEGUI::Window *sheet = CEGUI::System::getSingleton().getGUISheet();

            if (sheet)
                sheet->addChildWindow(mWindow);
            else
                CEGUI::System::getSingleton().setGUISheet(mWindow);

            mInput = static_cast<CEGUI::Editbox*> (CEGUI::WindowManager::getSingleton().getWindow("Input"));
            mOutput = static_cast<CEGUI::Editbox*> (CEGUI::WindowManager::getSingleton().getWindow("Output"));

            assert(mInput);
            assert(mOutput);

            BIND_CEGUI_EVENT(mInput, CEGUI::Editbox::EventTextAccepted, PythonConsole::onTextAccepted);
        } // if
    } // if
    mWindow->show();
}


void PythonConsole::hide()
{
    mWindow->hide();
}

bool PythonConsole::onTextAccepted(const CEGUI::EventArgs &args)
{
    return true;
}
