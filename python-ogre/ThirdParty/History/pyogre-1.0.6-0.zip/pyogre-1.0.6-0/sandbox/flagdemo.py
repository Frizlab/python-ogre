from pyogre import ogre
import SampleFramework

class FlagRenderable(ogre.SimpleRenderable):
    def __init__( self, width, height ):
        ogre.SimpleRenderable.__init__( self )
        self.width = width
        self.height = height
        self.vertexCount = width * height
        assert self.vertexCount < 64000 # limited to 16 bit indexes

        indexes = []
        for y in xrange(0,height-1):
            for x in xrange(0,width-1):
                indexes.append( self._makeIndex( x, y ) )
                indexes.append( self._makeIndex( x, y+1 ) )
                indexes.append( self._makeIndex( x+1, y ) )

                indexes.append( self._makeIndex( x+1, y ) )
                indexes.append( self._makeIndex( x, y+1 ) )
                indexes.append( self._makeIndex( x+1, y+1 ) )

        faceCount = (width-1) * (height-1) * 2
        assert faceCount == len(indexes) / 3
        self.faceNormals = [ ogre.Vector3.ZERO ] * faceCount
        assert len(self.faceNormals) == faceCount
        
        self.indexes = ogre.IndexData()
        self.indexes.indexCount = len( indexes )
        self.indexes.indexStart = 0
        self.indexes.indexBuffer = ogre.HardwareBufferManager.getSingleton().createIndexBuffer(
            ogre.HardwareIndexBuffer.IT_16BIT,
            len( indexes ),
            ogre.HardwareBuffer.HBU_STATIC_WRITE_ONLY,
            False )

        self.indexes.indexBuffer.writeIndexes( 0, indexes )

        self.vertexData = ogre.VertexData()
        self.vertexData.vertexStart = 0
        self.vertexData.vertexCount = self.vertexCount

        vDec = self.vertexData.vertexDeclaration
        vDec.addElement(0, vDec.getVertexSize(0), ogre.VET_FLOAT3, ogre.VES_POSITION, 0)
        declarationHelper.addElement( 0, vDec.getVertexSize(0), ogre.VET_FLOAT3, ogre.VES_POSITION, 0 )
        declarationHelper.addElement( 0, vDec.getVertexSize(0), ogre.VET_FLOAT3, ogre.VES_NORMAL, 0 )
        declarationHelper.addElement( 0, vDec.getVertexSize(0), ogre.VET_FLOAT2, ogre.VES_TEXTURE_COORDINATES, 0 )

        vertexBuffer = ogre.HardwareBufferManager.getSingleton().createVertexBuffer(
            declarationHelper.getVertexSize(0),
            self.vertexCount,
            ogre.HardwareBuffer.HBU_DYNAMIC_WRITE_ONLY, # usage, must discard on each update
            False )  # no shadow buffer
        self.vertexData.vertexBufferBinding.setBinding( 0, vertexBuffer )

        self.renderOp.operationType = ogre.RenderOperation.OT_TRIANGLE_LIST
        self.renderOp.useIndexes = True
        self.renderOp.indexData = self.indexes
        self.renderOp.vertexData = self.vertexData

    def updatePoints( self, points ):
        self._computeFaceNormals( points )
        buffer = self.vertexData.vertexBufferBinding.getBuffer(0)
        vertexesProxy = buffer.lock( self.vertexData.vertexDeclaration,
                                     ogre.HardwareBuffer.HBL_DISCARD )
        minPoint = ogre.Vector3( points[0] )
        maxPoint = ogre.Vector3( points[0] )
        index = 0
        for y in xrange(0,self.height):
            for x in xrange(0,self.width):
                point = points[index]
                minPoint.makeFloor( point )
                maxPoint.makeFloor( point )
                vertexesProxy.setFloat3( index, 0, point )

                normal = self._computeVertexNormal( x, y )
                vertexesProxy.setFloat3( index, 1, normal )

                u,v = float(x) / (self.width-1), float(y) / (self.height-1)
                vertexesProxy.setFloat2( index, 2, u, v )
                
                index += 1
##        print "* current vertex buffer:\n", vertexesProxy
        buffer.unlock()
        self.setBoundingBox( ogre.AxisAlignedBox( minPoint, maxPoint ) )

    def _makeIndex( self, x, y ):
        return x + y*self.width

    def _getFaceNormal( self, x, y, num ):
        return self.faceNormals[ 2* (x + y * (self.width-1)) + num ]

    def _setFaceNormals( self, x, y, normal0, normal1 ):
        index = 2* (x + y * (self.width-1) )
        self.faceNormals[ index ] = normal0
        self.faceNormals[ index+1 ] = normal1

    def _computeFaceNormals( self, points ):
        for y in xrange(0,self.height-1):
            for x in xrange(0,self.width-1):
                v00 = points[ self._makeIndex(x,y) ]
                v10 = points[ self._makeIndex(x+1,y) ]
                v01 = points[ self._makeIndex(x,y+1) ]
                v11 = points[ self._makeIndex(x+1,y+1) ]

                topLeftFaceNormal = (v10-v00).crossProduct( v01-v00 )
                bottomRightFaceNormal = (v10-v01).crossProduct( v11-v01 )
                self._setFaceNormals( x,y, topLeftFaceNormal, bottomRightFaceNormal )
        

    def _computeVertexNormal( self, x, y ):
        # * is our vertex, number are faces around the vertex
        #      /|2/
        #     /3|/1 
        #     --*--
        #     4/|0/ 
        #     /5|/
        # The vertex normal is computed by summing the normal of the faces around the vertex.
        normal = ogre.Vector3(0,0,0)
        if x < self.width-1:
            if y > 0:
                normal += self._getFaceNormal( x, y-1, 1 ) #face 1
                normal += self._getFaceNormal( x, y-1, 0 ) #face 2
                if x > 0:
                    normal += self._getFaceNormal( x-1, y-1, 1 ) #face 3
            if y < self.height-1:
                normal += self._getFaceNormal( x,y,0 ) # face0
        if x > 0 and y < self.height-1:
            normal += self._getFaceNormal( x-1,y,0 ) # face4
            normal += self._getFaceNormal( x-1,y,1 ) # face5
        normal.normalise()
        return normal

    # Overridden from Ogre::MovableObject
    def getBoundingRadius( self ):
        aab = self.getBoundingBox()
        minRadius = aab.getMinimum().length()
        maxRadius = aab.getMaximum().length()
        return max( minRadius, maxRadius )

    # Overridden from Ogre::Renderable
    def getSquaredViewDepth( self, camera ):
        aab = ogre.AxisAlignedBox( self.box )
        distance = aabb.getCenter() - camera.getPosition()
        return distance.squaredLength()


class FlagApplication(SampleFramework.Application):
    def _createScene( self ):
        sceneManager = self.sceneManager
        
        sceneManager.ambientLight = ogre.ColourValue(0.2,0.2,0.2)
        sceneManager.setSkyDome( True, 'Examples/CloudySky', 4.0, 8.0 )

        light = sceneManager.createLight( 'MainLight' )
        light.position = ( 20, 80, 50 )

##        plane = ogre.Plane()
##        plane.normal = ogre.Vector3.UNIT_Y
##        plane.d = 200
##        planeSpecification = ogre.PlaneSpecification( plane, 200000.0, 200000.0 )
##        planeSpecification.setTesselation( 20, 20 )
##        planeSpecification.setTiling( 50.0, 50.0 )
##        planeSpecification.upVector = ogre.Vector3.UNIT_Z
##        ogre.MeshManager.getSingleton().createPlane( 'FloorPlane',
##                                                     ogre.ResourceGroupManager.DEFAULT_RESOURCE_GROUP_NAME,
##                                                     planeSpecification )

##        # create floor entity
##        entity = sceneManager.createEntity( 'floor', 'FloorPlane' )
##        entity.setMaterialName( 'Examples/RustySteel' )
##        sceneManager.getRootSceneNode().createChildSceneNode().attachObject( entity )

        # create flag entity
        self.flag = FlagRenderable( 20, 20 )
        self.flag.setMaterial( 'Examples/Water5' )
        self._animateFlag()

        flagNode = sceneManager.getRootSceneNode().createChildSceneNode()
        flagNode.attachObject( self.flag )
        flagNode.translate( 0,0,-100 )

        # make sure the camera track this node
        self.camera.setAutoTracking( True, flagNode )

        # create the camera node & attach camera
        cameraNode = sceneManager.getRootSceneNode().createChildSceneNode()
        cameraNode.attachObject( self.camera )

        # set up spline animation of node
        animation = sceneManager.createAnimation( 'CameraTrack', 10 )
        animation.interpolationMode = ( ogre.Animation.IM_SPLINE )
        animationTrack = animation.createTrack( 0, cameraNode )
        key = animationTrack.createKeyFrame( 0 )
        key = animationTrack.createKeyFrame( 2.5 )
        key.setTranslate( ogre.Vector3( 500.0, 500.0, -1000.0 ) )
        key = animationTrack.createKeyFrame( 5 )
        key.setTranslate( ogre.Vector3( -1000.0, 500.0, -600.0 ) )
        key = animationTrack.createKeyFrame( 7.5 )
        key.setTranslate( ogre.Vector3( 0.0, 100.0, 0.0 ) )
        key = animationTrack.createKeyFrame( 10.0 )
        key.setTranslate( ogre.Vector3( 0.0, 0.0, 0.0 ) )
        self.animationState = sceneManager.createAnimationState( 'CameraTrack' )
        self.animationState.enabled = ( True )

        # add some fog
        sceneManager.setFog( ogre.FogMode.FOG_EXP, ogre.ColourValue.White, 0.0002 )

    def _animateFlag( self, t = 0.0 ):
        import math
        flag = self.flag
        vertexes = []
        x2pi = math.pi / flag.width
        y2pi = 0.5 * math.pi / flag.height
        t = (t % 10.0) * math.pi
        scale = 20.0
        offsetX = scale * flag.width / 2.0
        offsetY = scale * flag.height / 2.0
        for y in xrange(0, flag.height):
            for x in xrange(0, flag.width):
                vertexes.append( ogre.Vector3( x * scale - offsetX,
                                               y * scale - offsetY,
                                               50.0 * math.sin(2*x * x2pi + t+ y2pi * y ) ) )
        flag.updatePoints( vertexes )

    def _createFrameListener( self ):
        self.frameListener = FlagListener( self.renderWindow, self.camera, self.animationState, self._animateFlag )
        self.root.addFrameListener( self.frameListener )

    def _isPsycoEnabled( self ):
        return True

class FlagListener(SampleFramework.FrameListener):
    def __init__( self, renderWindow, camera, animationState, animateFlag ):
        SampleFramework.FrameListener.__init__( self, renderWindow, camera )
        self.animationState = animationState
        self.animateFlag = animateFlag
        self.time = 0.0

    def frameStarted( self, frameEvent ):
        self.animationState.addTime( frameEvent.timeSinceLastFrame )
        self.time += frameEvent.timeSinceLastFrame
        self.animateFlag( self.time )
        return SampleFramework.FrameListener.frameStarted( self, frameEvent )

if __name__ == '__main__':
    application = FlagApplication()
    application.go()
    
